package stepDefination_DSD_OMS.CustomerInqPage_ERPSteps;

import helper.HelpersMethod;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import pages_DSD_OMS.customerInquiry_ERP.*;
import pages_DSD_OMS.login.HomePage;
import pages_DSD_OMS.login.LoginPage;
import util.RandomValues;
import util.TestBase;

import java.util.List;

/**
 * @Project Divya.Ramadas@telusagcg.com
 * @Author Divya.Ramadas
 */
public class CustomerInqStep_ERP1
{
    /* Created by Divya.Ramadas */
    WebDriver driver;
    Scenario scenario;
    static CustomerInquiryPageERP customerInquiryPageERP;
    static IgnitionPageERP ignitionPageERP;
    static boolean flag2=false;

    @Before
    public void LaunchBrowser1(Scenario scenario) throws Exception
    {
        this.scenario=scenario;
        TestBase driver1=TestBase.getInstanceOfDriver();
        driver= driver1.getDriver();
    }

    @And("User should enter required details in ERP Copy popup and user should cancel copy")
    public void userShouldEnterRequiredDetailsInERPCopyPopupAndUserShouldCancelCopy()
    {
        customerInquiryPageERP=new CustomerInquiryPageERP(driver,scenario);
        customerInquiryPageERP.copyCustomerInqPopupCancel();
    }

    @Then("User refreshes customer inq page in ERP")
    public void userRefreshesCustomerInqPageInERP()
    {
        customerInquiryPageERP=new CustomerInquiryPageERP(driver,scenario);
        customerInquiryPageERP.Refresh_Page();
    }

    @And("User should select customer account# in customer inq in ERP")
    public void userShouldSelectCustomerAccountInCustomerInqInERP(DataTable dataTable)
    {
        List<List<String>> firstFilterValue = dataTable.asLists(String.class);
        customerInquiryPageERP=new CustomerInquiryPageERP(driver,scenario);
        customerInquiryPageERP.clickOnCustomerAccountIndex();
        customerInquiryPageERP.validateCustomerAccountIndex();
        customerInquiryPageERP.selectCustomerAccount(firstFilterValue.get(0).get(0));
        customerInquiryPageERP.NoNotePopHandling();
    }

    @Then("User should click on customer note icon in customer inq in ERP page and validate that note added is existing in popup")
    public void userShouldClickOnCustomerNoteIconInCustomerInqInERPPageAndValidateThatNoteAddedIsExistingInPopup(DataTable dataTable)
    {
        List<List<String>> custNote=dataTable.asLists(String.class);
        customerInquiryPageERP=new CustomerInquiryPageERP(driver,scenario);
        customerInquiryPageERP.clickOnNote();
        customerInquiryPageERP.validateNotePopup();
        customerInquiryPageERP.validateNoteInPopup(custNote.get(0).get(0));
        customerInquiryPageERP.clickOnOkButtonOfCustNote();
    }

    @Then("User clicks on Save button without entering customer name in ERP env")
    public void userClicksOnSaveButtonWithoutEnteringCustomerNameInERPEnv() throws InterruptedException
    {
        customerInquiryPageERP=new CustomerInquiryPageERP(driver,scenario);
        String billNo= RandomValues.generateRandomNumber(10);
        customerInquiryPageERP.BillNo(billNo);
        //customerInquiryPageERP.DescrVal();
        customerInquiryPageERP.Save_ButtonClick();
        customerInquiryPageERP.popUpForCustomerNameRequired();
    }
    
    @Then("User click on New button in ERP Customer Inq for copy of customer inq")
    public void userClickOnNewButtonInERPCustomerInqForCopyOfCustomerInq()
    {
        customerInquiryPageERP=new CustomerInquiryPageERP(driver,scenario);
        customerInquiryPageERP.ValidateCustomInq();
        customerInquiryPageERP.New_ButtonClick();
    }

    @And("User should click on save button to save copy of customer inq in ERP")
    public void userShouldClickOnSaveButtonToSaveCopyOfCustomerInqInERP() throws InterruptedException
    {
        customerInquiryPageERP=new CustomerInquiryPageERP(driver,scenario);
        customerInquiryPageERP.Save_ButtonClick();
    }

    @Then("User click on New button for copy of customer inq in ERP")
    public void userClickOnNewButtonForCopyOfCustomerInqInERP()
    {
        customerInquiryPageERP = new CustomerInquiryPageERP(driver, scenario);
        customerInquiryPageERP.ValidateCustomInq();
        customerInquiryPageERP.New_ButtonClick();
    }

    @Then("User should navigate to Telus tab in ERP")
    public void userShouldNavigateToTelusTabInERP()
    {
        if(flag2==false)
        {
            customerInquiryPageERP = new CustomerInquiryPageERP(driver, scenario);
            customerInquiryPageERP.NavigateDifferentTabs("TELUS OMS");
            if (HelpersMethod.IsExists("//div[@class='loader']", driver))
            {
                WebElement WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 1000000);
            }
            flag2 = true;
        }
        ignitionPageERP = new IgnitionPageERP(driver, scenario);
        ignitionPageERP.ValidateIgnition();
    }

    @And("User click on Payment processing and verify visibility of System default Realtime charge option in ERP")
    public void userClickOnPaymentProcessingAndVerifyVisibilityOfSystemDefaultRealtimeChargeOptionInERP()
    {
        customerInquiryPageERP=new CustomerInquiryPageERP(driver,scenario);
        customerInquiryPageERP.clickOnPaymentProcessing();
        customerInquiryPageERP.verifySystemDefaultRealTime();
    }

    @And("User should select customer account# in customer inq in ERP to load customer inq")
    public void userShouldSelectCustomerAccountInCustomerInqInERPToLoadCustomerInq()
    {

    }

    @And("User should verify that values relevant to the customer has been loaded in ERP")
    public void userShouldVerifyThatValuesRelevantToTheCustomerHasBeenLoadedInERP()
    {
        customerInquiryPageERP=new CustomerInquiryPageERP(driver,scenario);
        customerInquiryPageERP.readDetailsInMainPage();
    }

    @And("User should select customer account# in customer inq to load customer details in ERP")
    public void userShouldSelectCustomerAccountInCustomerInqToLoadCustomerDetailsInERP(DataTable dataTable)
    {
        List<List<String>> firstFilterValue = dataTable.asLists(String.class);
        customerInquiryPageERP=new CustomerInquiryPageERP(driver,scenario);
        customerInquiryPageERP.clickOnCustomerAccountIndex();
        customerInquiryPageERP.validateCustomerAccountIndex();
        customerInquiryPageERP.selectCustomerAccountNo(firstFilterValue.get(0).get(0));
        customerInquiryPageERP.NoNotePopHandling();
    }
}
