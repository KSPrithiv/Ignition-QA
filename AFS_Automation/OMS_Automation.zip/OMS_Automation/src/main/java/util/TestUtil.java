package util;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class TestUtil
{
    /* Created by Divya.Ramadas */
    public static final long PAGE_LOAD_TIMEOUT = 100;
    //public static final long IMPLICIT_WAIT=1;
}
