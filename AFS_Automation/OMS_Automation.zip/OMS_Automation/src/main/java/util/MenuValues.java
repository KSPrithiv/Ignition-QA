package util;

import org.aeonbits.owner.Config;

public interface MenuValues extends Config
{

}
