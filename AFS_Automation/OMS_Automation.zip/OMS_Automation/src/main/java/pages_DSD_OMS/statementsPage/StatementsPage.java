package pages_DSD_OMS.statementsPage;

import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import org.apache.commons.collections4.CollectionUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import pages_DSD_OMS.login.HomePage;
import util.TestBase;

import java.time.Duration;
import java.util.*;

import static com.fasterxml.jackson.databind.type.LogicalType.Array;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class StatementsPage
{
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    Scenario scenario;
    static boolean exists=false;
    static String currentURL;
    static ArrayList<String> customerAccNo=new ArrayList<>();
    static List<String> customerAccoNoString=new ArrayList<>();
    static ArrayList<String> customerAccNo1=new ArrayList<>();
    static ArrayList<String> customerName=new ArrayList<>();
    static ArrayList<String> customerName1=new ArrayList<>();
    static ArrayList<String> customerName2=new ArrayList<>();
    static List<WebElement> customers;

    @FindBy(id="cbStatementsWeekly")
    private WebElement weeklyCheckbox;

    @FindBy(id="cbStatementsMonthly")
    private WebElement monthlyCheckbox;

    @FindBy(id="cbStatementsRange")
    private WebElement dateCheckbox;

    @FindBy(id="ddlYear")
    private WebElement yearlyDropdown;

    @FindBy(id="ddlMonth")
    private WebElement monthDropdown;

    @FindBy(id="ddlDay")
    private WebElement dateDropdown;

    @FindBy(id="SearchBar1")
    private WebElement searchBar;

    @FindBy(xpath="//div[contains(@class,'i-search-box')]//*[local-name()='svg' and contains(@class,'i-search-box__search')]")
    private WebElement searchIndex;

    @FindBy(id="generateEditButton")
    private WebElement generateButton;

    private String pre;

    public StatementsPage(WebDriver driver, Scenario scenario)
    {
        this.driver=driver;
        this.scenario=scenario;
        PageFactory.initElements(driver,this);
    }

    //Actions
    public void NavigateStatements()
    {
        exists = false;
        WebElement WebEle = null;
        String status = null;
        status = HelpersMethod.returnDocumentStatus(driver);
        if (status.equals("loading"))
        {
            HelpersMethod.waitTillLoadingPage(driver);
        }
        try
        {
            status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            if (HelpersMethod.IsExists("//div[@class='loader']", driver))
            {
                WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 1000000);
            }

            Actions act = new Actions(driver);
            WebElement Search_Input = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='drawer-menu-search-container']/descendant::input");
            act.moveToElement(Search_Input).click().sendKeys("Statements").build().perform();
            WebElement StatementMenu = HelpersMethod.FindByElement(driver, "xpath", "//ul[contains(@class,'MuiList-root ')]/descendant::span[contains(text(),'Statements')]");
            HelpersMethod.ClickBut(driver, StatementMenu, 2000);
            Thread.sleep(4000);
            exists = true;
            status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            if (HelpersMethod.IsExists("//div[@class='loader']", driver))
            {
                WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 1000000);
            }
            status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            if(HelpersMethod.IsExists("//*[local-name()='svg']//*[local-name()='path' and contains(@d,'M3,18H21V16H3Zm0-5H21V11H3ZM3,6V8H21V6Z')]",driver))
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//*[local-name()='svg']//*[local-name()='path' and contains(@d,'M3,18H21V16H3Zm0-5H21V11H3ZM3,6V8H21V6Z')]");
                act.moveToElement(WebEle).build().perform();
                act.click(WebEle).build().perform();
            }
            currentURL=driver.getCurrentUrl();
            scenario.log(currentURL);
            if(HelpersMethod.IsExists("//ul[contains(@class,'MuiList-root ')]/descendant::span[contains(text(),'Statements')]",driver))
            {
                scenario.log("NAVIGATED TO STATEMENTS PAGE");
            }
            else
            {
                scenario.log("STATMENTS TAB MAY NOT BE ENABLED FOR THE APPLICATION");
            }
            Assert.assertEquals(exists, true);
        }
        catch (Exception e) {}
    }

    public void Refresh_Page() throws InterruptedException
    {
        scenario.log("CURRENT URL IS "+currentURL);
        driver.navigate().to(currentURL);
        String status = HelpersMethod.returnDocumentStatus(driver);
        if (status.equals("loading"))
        {
            HelpersMethod.waitTillLoadingPage(driver);
        }
        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                .withTimeout(Duration.ofSeconds(600))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
        Thread.sleep(4000);
    }

    public void ValidateStatements()
    {
        String PTitle=null;
        WebElement WebEle;
        String status="";
        try
        {
            status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            if(HelpersMethod.IsExists("//div[@class='loader']",driver))
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 100000);
            }
            PTitle=HelpersMethod.FindByElement(driver,"xpath","//span[contains(@class,'spnmoduleNameHeader')]").getText();
            if(PTitle.contains("Statements"))
            {
                scenario.log("USER IS ON STATEMENTS PAGE");
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void HandleError_Page()
    {
        try
        {
            String URL = HelpersMethod.gettingURL(driver);
            if (URL.contains("cpError"))
            {
                HelpersMethod.NavigateBack(driver);
                URL = HelpersMethod.gettingURL(driver);
                scenario.log("URL FOUND "+URL);
                scenario.log("**************ERROR PAGE HAS BEEN FOUND****************");
                driver.navigate().to(currentURL);
            }
            if (HelpersMethod.gettingURL(driver).contains("CPAdmin"))
            {
                HomePage homepage = new HomePage(driver, scenario);
                homepage.navigateToClientSide();
                NavigateStatements();
            }
        }
        catch (Exception e) {}
    }

    public void WeeklyCheckboxClick()
    {
        exists=false;
        try
        {
            if(!weeklyCheckbox.isSelected())
            {
                HelpersMethod.ClickBut(driver,weeklyCheckbox,1000);
            }
            if(weeklyCheckbox.isSelected())
            {
                scenario.log("WEEKLY CHECKBOX HAS BEEN SELECTED");
                exists = true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void MonthlyCheckboxClick()
    {
        exists=false;
        try
        {
            if(!monthlyCheckbox.isSelected())
            {
                HelpersMethod.ClickBut(driver,monthlyCheckbox, 1000);
            }
            if(monthlyCheckbox.isSelected())
            {
                scenario.log("MONTHLY CHECKBOX HAS BEEN SELECTED");
                exists = true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void DateCheckboxClick()
    {
        exists=false;
        try
        {
            if(!dateCheckbox.isSelected())
            {
                HelpersMethod.ClickBut(driver,dateCheckbox,1000);
            }
            if(dateCheckbox.isSelected())
            {
                scenario.log("DATE CHECKBOX HAS BEEN SELECTED");
                exists = true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void YearDropdown()
    {
        exists=false;
        Actions act=new Actions(driver);
        String prYear;
        String pYear;
        String status;
        WebElement YearFromDropDown;
        try
        {
            prYear=HelpersMethod.FindByElement(driver,"xpath","//span[@id='ddlYear']/span[contains(@class,'input')]").getText();
            scenario.log("YEAR BEFORE CHAINGING: "+prYear);
            HelpersMethod.ClickBut(driver,yearlyDropdown,1000);
            List<WebElement> Values=HelpersMethod.FindByElements(driver,"xpath","//ul[@id='ddlYear-listbox-id']/li/span");
            for(int i=0;i<= Values.size()-1;i++)
            {
                YearFromDropDown = Values.get(i);
                act.moveToElement(YearFromDropDown).build().perform();
                if(i==2)
                {
                    act.moveToElement(YearFromDropDown).build().perform();
                    act.click(YearFromDropDown).build().perform();
                    status = HelpersMethod.returnDocumentStatus(driver);
                    if (status.equals("loading"))
                    {
                        HelpersMethod.waitTillLoadingPage(driver);
                    }
                    exists=true;
                    break;
                }
            }
            status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            pYear=HelpersMethod.FindByElement(driver,"xpath","//span[@id='ddlYear']/span[contains(@class,'input')]").getText();
            scenario.log("YEAR AFTER CHAINGING: "+pYear);
//            if(prYear.equals(pYear))
//            {
//                scenario.log("FAILED TO CHANGE YEAR");
//                exists=false;
//            }
//            else if(!prYear.equals(pYear))
//            {
//                exists = true;
//            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void MonthDropdown()
    {
        exists=false;
        String prMonth;
        String pMonth;
        String status;
        WebElement monthFromDropDown;
        Actions act=new Actions(driver);
        try
        {
            prMonth = HelpersMethod.FindByElement(driver, "xpath", "//span[@id='ddlMonth']/span[contains(@class,'input')]").getText();
            scenario.log("MONTH BEFORE CHANGING: " + prMonth);
            HelpersMethod.ClickBut(driver, monthDropdown, 10000);
            Thread.sleep(1000);
            new WebDriverWait(driver,Duration.ofMillis(200000)).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@id='ddlMonth-listbox-id']/li/span"))));
            new WebDriverWait(driver, Duration.ofMillis(20000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@id='ddlMonth-listbox-id']/li/span")));
            Thread.sleep(1000);
            List<WebElement> Values = HelpersMethod.FindByElements(driver, "xpath", "//ul[@id='ddlMonth-listbox-id']/li/span");
            // get the len of Month list
            int maxMonth = Values.size();
            // get random number
            Random random = new Random();
            int randomMonth = random.nextInt(maxMonth);
            for (int i = 0; i <= maxMonth; i++)
            {
                act.moveToElement(Values.get(i)).build().perform();
                if(i==randomMonth)
                {
                    act.moveToElement(Values.get(i)).build().perform();
                    Thread.sleep(500);
                    act.click().build().perform();
                    exists=true;
                    break;
                }
            }
            status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            pMonth=HelpersMethod.FindByElement(driver,"xpath","//span[@id='ddlMonth']/span[contains(@class,'input')]").getText();
            scenario.log("MONTH AFTER CHANING: "+pMonth);
//            if(prMonth.equals(pMonth))
//            {
//                scenario.log("FAILED TO CHANGE MONTH");
//                exists = false;
//            }
//            else if(!prMonth.equals(pMonth))
//            {
//                exists=true;
//            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void DateDropdown()
    {
        exists=false;
        String prDate;
        String pDate;
        String status;
        Actions act=new Actions(driver);
        WebElement dateFromDropDown;
        try
        {
            prDate=HelpersMethod.FindByElement(driver,"xpath","//span[@id='ddlDay']/span[contains(@class,'input')]").getText();
            scenario.log("DATE BEFORE CHANGING: "+prDate);
            HelpersMethod.ClickBut(driver,dateDropdown,1000);
            List<WebElement> Values=HelpersMethod.FindByElements(driver,"xpath","//div[contains(@class,'k-animation-container ')]/descendant::ul/li");
            for(int i=0;i<= Values.size()-1;i++)
            {
                dateFromDropDown = Values.get(i);
                act.moveToElement(dateFromDropDown).build().perform();
                if(i==2)
                {
                    act.moveToElement(dateFromDropDown).build().perform();
                    act.click(dateFromDropDown).build().perform();
                    status = HelpersMethod.returnDocumentStatus(driver);
                    if (status.equals("loading"))
                    {
                        HelpersMethod.waitTillLoadingPage(driver);
                    }
                    exists=true;
                    break;
                }
            } status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            pDate=HelpersMethod.FindByElement(driver,"xpath","//span[@id='ddlDay']/span[contains(@class,'input')]").getText();
            scenario.log("DATE AFTER CHANGING: "+pDate);
//            if(prDate.equals(pDate))
//            {
//                scenario.log("FAILED TO CHANGE DATE");
//                exists=false;
//            }
//            else if(!prDate.equals(pDate))
//            {
//                exists = true;
//            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void SearchBar()
    {
        exists=false;
        String status;
        try
        {
            if(searchBar.isDisplayed())
            {
                HelpersMethod.EnterText(driver,searchBar,2000, TestBase.testEnvironment.additionalAccount());
                HelpersMethod.ActClick(driver,searchIndex,2000);
                Thread.sleep(4000);
                exists=true;
                status = HelpersMethod.returnDocumentStatus(driver);
                if (status.equals("loading"))
                {
                    HelpersMethod.waitTillLoadingPage(driver);
                }
            }
            else
            {
                scenario.log("SEARCH BAR IS NOT VISIBLE, CHECK ADMIN SETTINGS");
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void SelectCustomerNo()
    {
        exists=false;
        WebElement WebEle;
        String status="";
        try
        {
            Thread.sleep(2000);
            status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            if(!HelpersMethod.IsExists("//tr[contains(@class,'k-grid-norecords')]",driver))
            {
                WebEle = HelpersMethod.FindByElement(driver, "xpath", "//tr[contains(@class,'k-master-row')][1]/descendant::input[contains(@class,'checkbox')]");
                if(!WebEle.isSelected())
                {
                    HelpersMethod.ClickBut(driver,WebEle,4000);
                    scenario.log("CUSTOMER ACCOUNT NUMBER HAS BEEN SELECTED FOR STATEMENT");
                    status = HelpersMethod.returnDocumentStatus(driver);
                    if (status.equals("loading"))
                    {
                        HelpersMethod.waitTillLoadingPage(driver);
                    }
                }
                exists=true;
            }
            else
            {
                scenario.log("CUSTOMER ACCOUNT# DOESN'T EXISTS");
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void GenerateButtonWeekly()
    {
        exists=false;
        WebElement WebEle;
        String status;
        Wait<WebDriver> wait;
        try
        {
            String ParentWindow = driver.getWindowHandle();
            Thread.sleep(4000);
            new WebDriverWait(driver, Duration.ofMillis(200000)).until(ExpectedConditions.refreshed(ExpectedConditions.elementToBeClickable(By.id("generateEditButton"))));
            generateButton=HelpersMethod.FindByElement(driver,"id","generateEditButton");
            if(generateButton.isDisplayed() && generateButton.isEnabled())
            {
                HelpersMethod.ClickBut(driver, generateButton, 60000);
                status = HelpersMethod.returnDocumentStatus(driver);
                if (status.equals("loading"))
                {
                    HelpersMethod.waitTillLoadingPage(driver);
                }
                wait = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(800))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
            }
            Thread.sleep(1000);
            if(HelpersMethod.IsExists("//div[contains(text(),'There is no data to display for your defined date range')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                WebElement dialogPopup=HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'There is no data to display for your defined date range')]/ancestor::div[contains(@class,'k-window k-dialog')]");
                WebElement okButton=dialogPopup.findElement(By.xpath(".//button/span[text()='Ok']"));
                HelpersMethod.ActClick(driver,okButton,80000);
                scenario.log("***************THERE IS NO DATA TO DISPLAY IN THE SELECTED RANGE OF DATE**************");
                exists=true;
            }
            else
            {
                status = HelpersMethod.returnDocumentStatus(driver);
                if (status.equals("loading"))
                {
                    HelpersMethod.waitTillLoadingPage(driver);
                }
                Thread.sleep(10000);
                Set<String> allWindows = driver.getWindowHandles();
                if (allWindows.size() > 1)
                {
                    for (String handle : allWindows)
                    {
                        if (!handle.equals(ParentWindow))
                        {
                            // Switch to each child window
                            driver.switchTo().window(handle);
                            // Optionally check the URL or title to confirm if this is the window you want to close
                            String url = driver.getCurrentUrl();
                            scenario.log("Closing window with URL: " + url);
                            Thread.sleep(500);
                            // Use JavaScript to force-close the window
                            ((JavascriptExecutor) driver).executeScript("window.close();");
                            Thread.sleep(6000);
                            exists = true;
                        }
                    }
                }
                Thread.sleep(4000);
                // Switch back to the parent window
                driver.switchTo().window(ParentWindow);
                scenario.log("YOU ARE IN MAIN WINDOW");
                exists = true;

                wait = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(800))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void GenerateButton()
    {
        exists=false;
        WebElement WebEle;
        String status;
        try
        {
            String ParentWindow = driver.getWindowHandle();
            Thread.sleep(4000);
            new WebDriverWait(driver, Duration.ofMillis(200000)).until(ExpectedConditions.refreshed(ExpectedConditions.elementToBeClickable(By.id("generateEditButton"))));
            generateButton=HelpersMethod.FindByElement(driver,"id","generateEditButton");
            if(generateButton.isDisplayed() && generateButton.isEnabled())
            {
                HelpersMethod.ClickBut(driver, generateButton, 60000);
                status = HelpersMethod.returnDocumentStatus(driver);
                if (status.equals("loading"))
                {
                    HelpersMethod.waitTillLoadingPage(driver);
                }
                if (HelpersMethod.IsExists("//div[@class='loader']", driver))
                {
                    WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='loader']");
                    HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 800000);
                }
            }
            Thread.sleep(6000);
            if(HelpersMethod.IsExists("//div[contains(text(),'There is no data to display for your defined date range')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                WebElement dialogPopup=HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'There is no data to display for your defined date range')]/ancestor::div[contains(@class,'k-window k-dialog')]");
                WebElement okButton=dialogPopup.findElement(By.xpath(".//button/span[text()='Ok']"));
                HelpersMethod.ActClick(driver,okButton,8000);
                scenario.log("***************THERE IS NO DATA TO DISPLAY IN THE SELECTED RANGE OF DATE**************");
                exists=true;
            }
            else
            {
                Wait<WebDriver>  wait = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(800))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
                status = HelpersMethod.returnDocumentStatus(driver);
                if (status.equals("loading"))
                {
                    HelpersMethod.waitTillLoadingPage(driver);
                }
                wait = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(800))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

                Thread.sleep(10000);
                Set<String> allWindows = driver.getWindowHandles();
                if (allWindows.size() > 1)
                {
                    for (String handle : allWindows)
                    {
                        if (!handle.equals(ParentWindow))
                        {
                            // Switch to each child window
                            driver.switchTo().window(handle);
                            // Optionally check the URL or title to confirm if this is the window you want to close
                            String url = driver.getCurrentUrl();
                            scenario.log("Closing window with URL: " + url);
                            Thread.sleep(500);
                            // Use JavaScript to force-close the window
                            ((JavascriptExecutor) driver).executeScript("window.close();");
                            Thread.sleep(8000);
                            exists = true;
                        }
                    }
                }
                Thread.sleep(4000);
                // Switch back to the parent window
                driver.switchTo().window(ParentWindow);
                scenario.log("YOU ARE IN MAIN WINDOW");
                exists = true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void SearchValidation()
    {
        exists = false;
        try
        {
            if (HelpersMethod.IsExists("//tr[contains(@class,'k-grid-norecords')]", driver))
            {
                scenario.log("NO CUSTOMER ACCOUNT# HAS BEEN FOUND");
                exists = true;
            }
            else
            {
                scenario.log("CUSTOMER ACCOUNT# HAS BEEN FOUND");
                exists = true;
            }
            Assert.assertEquals(exists, true);
        }
        catch (Exception e) {}
    }

    public void AddFilterSearch()
    {
        exists=false;
        WebElement Search2;
        WebElement Clear;
        String SearhBox2Value=TestBase.testEnvironment.get_Account();
        try
        {
            //Click on Add filter button
            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.elementToBeClickable(By.xpath("//button/descendant::span[contains(text(),'Add filter')]")));
            driver.findElement(By.xpath("//button/descendant::span[contains(text(),'Add filter')]")).click();

            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//div[contains(@class,'k-animation-container k-animation-container-shown')]",80000);
            WebElement modalContainer1=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-animation-container k-animation-container-shown')]");

            //Click on Clear all button
            if(HelpersMethod.IsExists("//button[contains(@class,'k-button k-button-md k-button-flat k-button-flat-primary k-rounded-md i-filter-popup__footer__button i-primary')]/span[contains(text(),'Clear all')]",driver))
            {
                Clear = modalContainer1.findElement(By.xpath(".//button[contains(@class,'k-button k-button-md k-button-flat k-button-flat-primary k-rounded-md i-filter-popup__footer__button i-primary')]/span[contains(text(),'Clear all')]"));
                if (Clear.isEnabled())
                {
                    Clear.click();
                }
            }

            WebElement Search1=modalContainer1.findElement(By.xpath(".//input[contains(@class,'i-search-box__input')]"));
            HelpersMethod.ActSendKey(driver,Search1,10000,"Customer account #");
            //Click on Check box
            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.elementToBeClickable(By.xpath(".//input[contains(@class,'k-checkbox')]")));
            WebElement WebEle1=modalContainer1.findElement(By.xpath(".//input[contains(@class,'k-checkbox')]"));
            HelpersMethod.ClickBut(driver,WebEle1,10000);

            //Identify radio button and click on Radio button
            new WebDriverWait(driver,Duration.ofMillis(80000)).until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//div[contains(@class,'i-btn-radio filter-radio')]/ancestor::div[contains(@class,'k-child-animation-container')]")));
            new WebDriverWait(driver,Duration.ofMillis(80000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'i-btn-radio filter-radio')]/ancestor::div[contains(@class,'k-child-animation-container')]")));
            if(HelpersMethod.IsExists("//div[contains(@class,'i-btn-radio filter-radio')]/ancestor::div[contains(@class,'k-child-animation-container')]",driver))
            {
                WebElement RadioPop=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-child-animation-container')]/descendant::form[contains(@class,'i-filter-popup')]");
                Search2=RadioPop.findElement(By.xpath(".//div[contains(@class,'i-btn-radio filter-radio')][1]/following-sibling::div[contains(@class,'k-textbox-container i-filter-popup__content__input')]/input"));
                HelpersMethod.EnterText(driver,Search2,10000,SearhBox2Value);

                //Click on Apply button
                Clear =RadioPop.findElement(By.xpath(".//button/span[text()='Apply']"));
                HelpersMethod.ClickBut(driver,Clear,10000);
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void FromDate()
    {
        WebElement WebEle;
        try
        {
            WebEle= HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-textbox-container')][1]/descendant::a[contains(@class,'k-select k-select')]");
            HelpersMethod.ClickBut(driver,WebEle,1000);
            HelpersMethod.WaitElementPresent(driver,"xpath","//div[contains(@class,'k-calendar-view k-calendar-monthview')]",4000);
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//div[contains(@class,'k-calendar-view k-calendar-monthview')]",4000);

            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-content k-calendar-content k-scrollable')]/table[contains(@class,'k-calendar-table')]/descendant::tr[3]/td[1]/span");
            HelpersMethod.ClickBut(driver,WebEle,1000);
        }
        catch (Exception e){}
    }

    public void ToDate()
    {
        WebElement WebEle;
        try
        {
            WebEle= HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-textbox-container')][2]/descendant::a[contains(@class,'k-select k-select')]");
            HelpersMethod.ClickBut(driver,WebEle,1000);
            HelpersMethod.WaitElementPresent(driver,"xpath","//div[contains(@class,'k-calendar-view k-calendar-monthview')]",4000);
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//div[contains(@class,'k-calendar-view k-calendar-monthview')]",4000);

            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-content k-calendar-content k-scrollable')]/table[contains(@class,'k-calendar-table')]/descendant::tr/td[contains(@class,'k-calendar-td k-state-pending-focus k-state-selected k-today')]");
            HelpersMethod.ClickBut(driver,WebEle,1000);
        }
        catch (Exception e){}
    }

    public void readAllCustomerAccount()
    {
        String customerText;
        Actions act=new Actions(driver);
       try
       {
           customers=HelpersMethod.FindByElements(driver,"xpath","//tr[contains(@class,'k-master-row')]/descendant::td[@data-grid-col-index='1']");
           for(WebElement customer:customers)
           {
               act.moveToElement(customer).build().perform();
               customerText=customer.getText();
               customerAccNo.add(customerText);
           }
           scenario.log("Customer account # found "+customerAccNo.size());
           //Display first 10 customer account#
           scenario.log("DISPLAYING FIRST 10 CUSTOMER ACCOUNT#");
           for(int i=0;i<=10;i++)
           {
               scenario.log(customerAccNo.get(i));
           }
       }
       catch (Exception e){}
    }

    public void moveToCustomerAccountNoColumn()
    {
        Actions act=new Actions(driver);
        exists=false;
        try
        {
            WebElement custAccColumn=HelpersMethod.FindByElement(driver,"xpath","//th[contains(@class,'k-filterable k-table-th k-header')][1]");
            act.moveToElement(custAccColumn).click().build().perform();
            if(HelpersMethod.IsExists("//th[contains(@class,'k-filterable k-table-th k-header')][1]/descendant::span[contains(@class,'sort-asc-small')]",driver))
            {
                scenario.log("CUSTOMER ACCOUNT# SHOULD BE ARRANGED IN ACENDING ORDER NOW");
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void readAllCustomerAccountAfterSorting()
    {
        String customerText;
        Actions act=new Actions(driver);
        try
        {
            customers=HelpersMethod.FindByElements(driver,"xpath","//tr[contains(@class,'k-master-row')]/descendant::td[@data-grid-col-index='1']");
            for(WebElement customer:customers)
            {
                act.moveToElement(customer).build().perform();
                customerText=customer.getText();
                customerAccNo1.add(customerText);
            }
            //Display first 10 customer account#
            scenario.log("DISPLAYING FIRST 10 CUSTOMER ACCOUNT#");
            for(int i=0;i<=10;i++)
            {
                scenario.log(customerAccNo1.get(i));
            }
        }
        catch (Exception e){}
    }

    public void validatingSorting()
    {
        exists=false;
        try
        {
                customerAccoNoString = customerAccNo1;
                customerAccoNoString.sort(String::compareTo);
                for(int i=0;i<=customerAccNo1.size()-1;i++)
                {
                    scenario.log("\n\n ");
                    scenario.log("SORTED VALUE IN UI "+customerAccNo1.get(i)+" SORTED VALUE IN AUTOMATION "+customerAccoNoString.get(i));
                }
                if(customerAccoNoString.equals(customerAccNo1))
                {
                    scenario.log("CUSTOMER ACCOUNT NUMBERS ARE IN ASCENDING ORDER");
                    exists=true;
                }
                else
                {
                    scenario.log("<span 'color:red'>ACCOUNT NUMBER MAY NOT BE SORTED</span>");
                    exists = false;
                }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void readAllCustomerName()
    {
        String customerText;
        Actions act=new Actions(driver);
        try
        {
            customers=HelpersMethod.FindByElements(driver,"xpath","//tr[contains(@class,'k-master-row')]/descendant::td[@data-grid-col-index='2']");
            for(WebElement customer:customers)
            {
                act.moveToElement(customer).build().perform();
                customerText=customer.getText();
                customerName.add(customerText);
            }
            scenario.log("TOTAL NUMBER OF CUSTOMER NAME FOUND "+customerName.size());
            //Display first 10 customer account#
            scenario.log("DISPLAYING FIRST 10 CUSTOMER NAME");
            for(int i=0;i<=10;i++)
            {
                scenario.log(customerName.get(i));
            }
        }
        catch (Exception e){}
    }

    public void moveToCustomerNameColumn()
    {
        Actions act=new Actions(driver);
        exists=false;
        try
        {
            WebElement custNameColumn=HelpersMethod.FindByElement(driver,"xpath","//th[contains(@class,'k-filterable k-table-th k-header')][2]");
            act.moveToElement(custNameColumn).click().build().perform();
            if(HelpersMethod.IsExists("//th[contains(@class,'k-filterable k-table-th k-header')][2]/descendant::span[contains(@class,'sort-asc-small')]",driver))
            {
                scenario.log("CUSTOMER NAME SHOULD BE ARRANGED IN ACENDING ORDER NOW");
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void readAllCustomerNameAfterSorting()
    {
        String customerText;
        Actions act=new Actions(driver);
        try
        {
            customers=HelpersMethod.FindByElements(driver,"xpath","//tr[contains(@class,'k-master-row')]/descendant::td[@data-grid-col-index='2']");
            for(WebElement customer:customers)
            {
                act.moveToElement(customer).build().perform();
                customerText=customer.getText();
                customerName1.add(customerText);
            }
            //Display first 10 customer account#
            scenario.log("DISPLAYING FIRST 10 CUSTOMER NAME");
            for(int i=0;i<=10;i++)
            {
                scenario.log(customerName1.get(i));
            }
        }
        catch (Exception e){}
    }

    public void validatingCustomerNameSorting()
    {
        exists=false;
        try
        {
            customerName2=customerName1;
            Collections.sort(customerName2, String.CASE_INSENSITIVE_ORDER);
            for(int i=0;i<=customerName1.size()-1;i++)
            {
                scenario.log("SORTED VALUE IN UI "+customerName1.get(i)+" SORTED VALUE IN AUTOMATION "+customerName2.get(i));
            }
           if(CollectionUtils.isEqualCollection(customerName2, customerName1))
           {
               exists=true;
           }
           Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void AddFilterClear()
    {
        exists=false;
        WebElement Clear;
        try
        {
            //Click on Add filter button
            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.elementToBeClickable(By.xpath("//button/descendant::span[contains(text(),'Add filter')]")));
            driver.findElement(By.xpath("//button/descendant::span[contains(text(),'Add filter')]")).click();

            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//div[contains(@class,'k-animation-container k-animation-container-shown')]",80000);
            WebElement modalContainer1=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-animation-container k-animation-container-shown')]");

            //Click on Clear all button
            if(HelpersMethod.IsExists("//button[contains(@class,'k-button k-button-md k-button-flat k-button-flat-primary k-rounded-md i-filter-popup__footer__button i-primary')]/span[contains(text(),'Clear all')]",driver))
            {
                Clear = modalContainer1.findElement(By.xpath(".//button[contains(@class,'k-button k-button-md k-button-flat k-button-flat-primary k-rounded-md i-filter-popup__footer__button i-primary')]/span[contains(text(),'Clear all')]"));
                if (Clear.isEnabled())
                {
                    Clear.click();
                    scenario.log("ADD FILTER CLEAR ALL BUTTON CLICKED");
                    exists=true;
                }
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void readTotalCustomerDisplayedValueAfterClearAll()
    {
        exists=false;
        String totalCustomer;
        int totalCustomerInt;
        try
        {
            totalCustomer=HelpersMethod.FindByElement(driver,"xpath","//span[contains(text(),'Items found')]/following-sibling::span").getText();
            totalCustomerInt=Integer.parseInt(totalCustomer);
            if(totalCustomerInt>1)
            {
                scenario.log("TOTAL NUMBER OF CUSTOMER DISPLAYED AFTER FILTER: " + totalCustomer);
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void readTotalCustomerDisplayedValueAfterFilter()
    {
        exists=false;
        String totalCustomer;
        int totalCustomerInt;
        try
        {
            totalCustomer=HelpersMethod.FindByElement(driver,"xpath","//span[contains(text(),'Items found')]/following-sibling::span").getText();
            totalCustomerInt=Integer.parseInt(totalCustomer);
            if(totalCustomerInt==1)
            {
                scenario.log("TOTAL NUMBER OF CUSTOMER DISPLAYED AFTER FILTER: " + totalCustomer);
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }
}