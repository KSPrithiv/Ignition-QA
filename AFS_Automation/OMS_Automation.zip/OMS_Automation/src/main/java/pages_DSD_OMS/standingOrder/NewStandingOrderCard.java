package pages_DSD_OMS.standingOrder;

import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import io.cucumber.java.bs.A;
import lombok.val;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.v85.network.model.DataReceived;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import util.Environment;
import util.TestBase;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class NewStandingOrderCard
{
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    Scenario scenario;
    static boolean exists=false;
    static String fromGenerateDate;
    static String toGenerateDate;
    static ArrayList<String> daysText = new ArrayList<String>();

    @FindBy(id="addStandingOrder")
    private WebElement StartStandingOrder;

    @FindBy(id="copyStandingOrder")
    private WebElement CopyStandingOrder;

    @FindBy(id="deleteStandingOrder")
    private WebElement DeleteStandingOrder;

    @FindBy(id="generateStandingOrders")
    private WebElement GenerateStandingOrder;

    @FindBy(id="showStandingOrderRegisterButton")
    private WebElement ShowStandingOrder;

    public NewStandingOrderCard(WebDriver driver, Scenario scenario)
    {
        this.driver=driver;
        this.scenario=scenario;
        PageFactory.initElements(driver,this);
    }

    //Action
    public void ClickOnNewStandingOrderArrow() throws InterruptedException
    {
        exists = false;
        WebElement WebEle = null;
        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                .withTimeout(Duration.ofSeconds(600))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

        //Click on arrow if Start standing order card is not visible
        if (HelpersMethod.IsExists("//div[contains(@class,'StandingOrder-expandable-card')]/descendant::span[contains(@class,'k-icon k-i-arrow-chevron-down')]", driver))
        {
            WebEle= HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'StandingOrder-expandable-card')]/descendant::span[contains(@class,'k-icon k-i-arrow-chevron-down')]");
            new WebDriverWait(driver,Duration.ofMillis(20000)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'StandingOrder-expandable-card')]/descendant::span[contains(@class,'k-icon k-i-arrow-chevron-down')]")));
            new WebDriverWait(driver,Duration.ofMillis(20000)).until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class,'StandingOrder-expandable-card')]/descendant::span[contains(@class,'k-icon k-i-arrow-chevron-down')]")));
            HelpersMethod.ScrollElement(driver, WebEle);
            HelpersMethod.ActClick(driver, WebEle, 50000);
            String status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
        }
    }

    public void ClickOnStartStandingOrder() throws InterruptedException
    {
        exists = false;
        try
        {
            Thread.sleep(4000);
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            if (HelpersMethod.IsExists("//span[contains(@class,'k-icon k-i-arrow-chevron-up')]", driver))
            {
                if (StartStandingOrder.isDisplayed() && StartStandingOrder.isEnabled())
                {
                    HelpersMethod.ScrollElement(driver, StartStandingOrder);
                    HelpersMethod.ClickBut(driver, StartStandingOrder, 10000);
                    scenario.log("START STANDING ORDER BUTTON CLICKED");
                    String status = HelpersMethod.returnDocumentStatus(driver);
                    if (status.equals("loading"))
                    {
                        HelpersMethod.waitTillLoadingPage(driver);
                    }
                    new WebDriverWait(driver, Duration.ofMillis(40000)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Add standing order')]/ancestor::div[contains(@class,'k-window k-dialog')]")));
                    HelpersMethod.waitTillElementLocatedDisplayed(driver, "xpath", "//span[contains(text(),'Add standing order')]/ancestor::div[contains(@class,'k-window k-dialog')]", 80000);
                    exists = true;
                }
            }
            Assert.assertEquals(exists, true);
        }
        catch (Exception e){}
    }

    //Code to select start date and end date for standing order
    public void VerifyCalenderPopupStandingOrder() throws InterruptedException
    {
        WebElement WebEle;
        String FTDate;
        try
        {
            String status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }

            //Create WebElement for popup
            WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");

            //Click on From Calender icon
            WebElement startDateIcon = modalContainer.findElement(By.xpath(".//input[@id='addFromDate']/parent::span/following-sibling::button"));
            HelpersMethod.ClickBut(driver, startDateIcon, 10000);


             status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']")));
            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']"))));

            Thread.sleep(1000);
            //Select 'From' date from Start date calender
            if (HelpersMethod.IsExists("//div[@id='addFromDate-popup-id']", driver))
            {
                // to fetch the web element of the modal container
                WebElement ele1 = HelpersMethod.FindByElement(driver,"xpath","//table[@class='k-calendar-table']/descendant::td[contains(@class,'k-focus')]/span");
                if (ele1.isDisplayed() && ele1.isEnabled())
                {
                    HelpersMethod.JSScroll(driver, ele1);
                    HelpersMethod.JScriptClick(driver, ele1, 10000);
                    exists = true;
                    status = HelpersMethod.returnDocumentStatus(driver);
                    if (status.equals("loading"))
                    {
                        HelpersMethod.waitTillLoadingPage(driver);
                    }
                    WebEle = HelpersMethod.FindByElement(driver, "id", "addFromDate");
                    FTDate = HelpersMethod.JSGetValueEle(driver, WebEle, 10000);
                    scenario.log(FTDate + " HAS BEEN SELECTED AS START DATE FOR STANDING ORDER");
                }
                else
                {
                    scenario.log("FAILED TO SELECT START DATE");
                }
            }

            //Click on To calender icon
            WebElement toDateIcon = modalContainer.findElement(By.xpath(".//input[@id='addToDate']/parent::span/following-sibling::button"));
            HelpersMethod.ClickBut(driver, toDateIcon, 10000);

            //new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='addToDate-popup-id']")));
            status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='addToDate-popup-id']"))));
            new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='addToDate-popup-id']")));

            Thread.sleep(500);
            //Select 'To' date from End date calender
            if (HelpersMethod.IsExists("//div[@id='addToDate-popup-id']", driver))
            {
                // to fetch the web element of the modal container
                WebElement ele1 = HelpersMethod.FindByElement(driver,"xpath","//table[@class='k-calendar-table']/descendant::td[contains(@class,'k-focus')]/span");
                if (ele1.isDisplayed() && ele1.isEnabled())
                {
                    HelpersMethod.JSScroll(driver, ele1);
                    HelpersMethod.JScriptClick(driver, ele1, 10000);
                    exists = true;
                    status = HelpersMethod.returnDocumentStatus(driver);
                    if (status.equals("loading"))
                    {
                        HelpersMethod.waitTillLoadingPage(driver);
                    }
                    WebEle = HelpersMethod.FindByElement(driver, "id", "addToDate");
                    FTDate = HelpersMethod.JSGetValueEle(driver, WebEle, 10000);
                    scenario.log(FTDate + " HAS BEEN SELECTED AS END DATE FOR STANDING ORDER");
                }
                else
                {
                    scenario.log("FAILED TO SELECT START DATE");
                }
            }
            //Click on ADD button
            WebEle = modalContainer.findElement(By.xpath(".//button/span[text()='Add']"));
            HelpersMethod.ActClick(driver, WebEle, 10000);
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
        }
        catch (Exception e){}
    }

    public void validateStartAddStandingOrderPopup()
    {
        exists=false;
        try
        {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            new WebDriverWait(driver,Duration.ofMillis(40000)).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Add standing order')]/ancestor::div[contains(@class,'k-window k-dialog')]"))));
            new WebDriverWait(driver,Duration.ofMillis(40000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Add standing order')]/ancestor::div[contains(@class,'k-window k-dialog')]")));
            Thread.sleep(4000);

            //HelpersMethod.waitTillElementLocatedDisplayed(driver, "xpath", "//span[contains(text(),'Add standing order')]/ancestor::div[contains(@class,'k-window k-dialog')]", 10000);
            if (HelpersMethod.IsExists("//span[contains(text(),'Add standing order')]/ancestor::div[contains(@class,'k-window k-dialog')]", driver))
            {
                scenario.log("ADD STANDING ORDER DIALOG BOX FOUND");
                exists = true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void ClickOnStartDateCalender() throws InterruptedException
    {
        exists=false;
        try
        {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            new WebDriverWait(driver,Duration.ofMillis(20000)).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Add standing order')]/ancestor::div[contains(@class,'k-window k-dialog')]"))));
            new WebDriverWait(driver,Duration.ofMillis(20000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Add standing order')]/ancestor::div[contains(@class,'k-window k-dialog')]")));
            new WebDriverWait(driver,Duration.ofMillis(80000)).until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class,'k-window k-dialog')]/descendant::input[@id='addFromDate']/parent::span/following-sibling::button")));
            Thread.sleep(8000);
            // to fetch the web element of the modal container
            WebElement modalContainer = driver.findElement(By.xpath("//div[contains(@class,'k-window k-dialog')]"));
            WebElement startDateIcon = modalContainer.findElement(By.xpath(".//input[@id='addFromDate']/parent::span/following-sibling::button"));
            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(startDateIcon)));
            new WebDriverWait(driver, Duration.ofMillis(80000)).until(ExpectedConditions.elementToBeClickable(startDateIcon));
            HelpersMethod.ActClick(driver, startDateIcon, 40000);
            exists = true;
            new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']")));
            HelpersMethod.WaitElementPresent(driver, "xpath", "//div[@id='addFromDate-popup-id']", 10000);

            String status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']")));
            Assert.assertEquals(exists, true);
        }
        catch (Exception e){}
    }

    public void ClickOnEndDateCalender() throws InterruptedException
    {
        try
        {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            HelpersMethod.waitTillElementLocatedDisplayed(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]", 10000);
            new WebDriverWait(driver,Duration.ofMillis(20000)).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'k-window k-dialog')]/descendant::input[@id='addToDate']/parent::span/following-sibling::button"))));
            new WebDriverWait(driver,Duration.ofMillis(20000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'k-window k-dialog')]/descendant::input[@id='addToDate']/parent::span/following-sibling::button")));
            new WebDriverWait(driver,Duration.ofMillis(20000)).until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class,'k-window k-dialog')]/descendant::input[@id='addToDate']/parent::span/following-sibling::button")));
            Thread.sleep(6000);

            // to fetch the web element of the modal container
            WebElement modalContainer = driver.findElement(By.xpath("//div[contains(@class,'k-window k-dialog')]"));
            WebElement toDateIcon = modalContainer.findElement(By.xpath(".//input[@id='addToDate']/parent::span/following-sibling::button"));
            HelpersMethod.ActClick(driver, toDateIcon, 60000);
            HelpersMethod.WaitElementPresent(driver, "xpath", "//div[@class='k-calendar-view k-vstack k-calendar-monthview']", 10000);
            new WebDriverWait(driver, Duration.ofMillis(40000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']")));
            String status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']"))));
            new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']")));
        }
        catch (Exception e){}
    }

    //Selecting Start date
    public void SelectStartDate(int i) throws InterruptedException
    {
        String formattedDate1;
        WebElement WebEle;
        String FTDate;
        exists=false;
        try
        {
            LocalDate myDateObj = LocalDate.now().plusDays(i);
            DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy");
            formattedDate1 = myDateObj.format(myFormatObj);
            new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']")));

            String status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            new WebDriverWait(driver,Duration.ofMillis(60000)).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']"))));
            new WebDriverWait(driver, Duration.ofMillis(60000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']")));

            //Visibility of Start calender
            if (HelpersMethod.IsExists("//div[@id='addFromDate-popup-id']", driver))
            {
                // to fetch the web element of the modal container
                WebElement fromDateContainer = driver.findElement(By.xpath("//table[@class='k-calendar-table']"));
                WebElement ele1 = fromDateContainer.findElement(By.xpath(".//td[contains(@title,'" + formattedDate1 + "')]/span"));
                if (ele1.isDisplayed() && ele1.isEnabled())
                {
                    HelpersMethod.JSScroll(driver, ele1);
                    HelpersMethod.JScriptClick(driver, ele1, 10000);
                    exists = true;
                    status = HelpersMethod.returnDocumentStatus(driver);
                    if (status.equals("loading"))
                    {
                        HelpersMethod.waitTillLoadingPage(driver);
                    }
                    WebEle = HelpersMethod.FindByElement(driver, "id", "addFromDate");
                    FTDate = HelpersMethod.JSGetValueEle(driver, WebEle, 10000);
                    scenario.log(FTDate + " HAS BEEN SELECTED AS START DATE FOR STANDING ORDER");
                }
                else
                {
                    scenario.log("FAILED TO SELECT START DATE");
                }
            }
            new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']")));
            Assert.assertEquals(exists, true);
        }
        catch (Exception e){}
    }

    //selecting end date
    public void SelectEndDate(int i) throws InterruptedException
    {
        String formattedDate1;
        String FTDate;
        WebElement WebEle;
        exists=false;
        try
        {
            LocalDate myDateObj = LocalDate.now().plusDays(i);
            DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy");
            formattedDate1 = myDateObj.format(myFormatObj);

            new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']")));
            String status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']")));
            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']"))));

            //Visibility of End calender
            if (HelpersMethod.IsExists("//div[@id='addToDate-popup-id']", driver))
            {
                // to fetch the web element of the modal container
                WebElement fromDateContainer = driver.findElement(By.xpath("//table[@class='k-calendar-table']"));

                WebElement ele1 = fromDateContainer.findElement(By.xpath(".//td[contains(@title,'" + formattedDate1 + "')]/span"));
                if (ele1.isDisplayed() && ele1.isEnabled())
                {
                    HelpersMethod.JSScroll(driver, ele1);
                    HelpersMethod.JScriptClick(driver, ele1, 10000);
                    exists = true;
                    status = HelpersMethod.returnDocumentStatus(driver);
                    if (status.equals("loading"))
                    {
                        HelpersMethod.waitTillLoadingPage(driver);
                    }
                    WebEle = HelpersMethod.FindByElement(driver, "id", "addToDate");
                    FTDate = HelpersMethod.JSGetValueEle(driver, WebEle, 10000);
                    scenario.log(FTDate + " HAS BEEN SELECTED AS END DATE FOR STANDING ORDER");
                }
                else
                {
                    scenario.log("FAILED TO SELECT END DATE");
                }
            }
            new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']")));
            Assert.assertEquals(exists, true);
        }
        catch (Exception e){}
    }

    public void AddStartStandingOrder() throws InterruptedException
    {
        exists=false;
        WebElement WebEle;
        try
        {
            //Click on Add button
            HelpersMethod.waitTillElementLocatedDisplayed(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]", 10000);
            WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");

            // Verify the title of Add standin order popup
            WebElement modalContentTitle = modalContainer.findElement(By.xpath(".//span[contains(@class,'k-window-title k-dialog-title')]"));
            //Assert.assertEquals(modalContentTitle.getText(), "Add standing order", "Verify Title message");
            if(modalContentTitle.getText().equals("Add standing order"))
            {
                WebEle = modalContainer.findElement(By.xpath(".//button/span[text()='Add']"));
                HelpersMethod.ActClick(driver, WebEle, 10000);
                exists = true;
                Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(600))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
            }
            else
            {
                exists=false;
            }
            Assert.assertEquals(exists, true);
        }
        catch (Exception e){}
    }

    public void DeleteStandingOrders() throws InterruptedException
    {
        try
        {
            exists = false;
            WebElement WebEle;
            int i=0;
            List<WebElement> StandingOrders = HelpersMethod.FindByElements(driver, "xpath", "//div[contains(@class,'standing-orders')]/descendant::span[contains(@class,'pending')]/ancestor::button|//div[contains(@class,'standing-orders')]/descendant::span[contains(@class,'standing-orders-status active  ')]/ancestor::button");
            scenario.log("TOTAL NUMBER OF ACTIVE AND PENDING SO FOUND ARE " + StandingOrders.size());
            while(!StandingOrders.isEmpty())
            {
                i++;
                scenario.log(i+" STANDING ORDER HAS BEEN DELETED");
                WebElement SO=StandingOrders.get(0);
                HelpersMethod.ScrollElement(driver, SO);
                HelpersMethod.ActClick(driver, SO, 10000);
                String status = HelpersMethod.returnDocumentStatus(driver);
                if (status.equals("loading"))
                {
                    HelpersMethod.waitTillLoadingPage(driver);
                }
                Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(600))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

                //Click on down arrow in standing order card
                ClickOnNewStandingOrderArrow();
                HelpersMethod.ClickBut(driver, DeleteStandingOrder, 10000);
                if (HelpersMethod.IsExists("//span[contains(text(),'Delete standing order?')]/ancestor::div[contains(@class,'k-window k-dialog')]", driver))
                {
                    WebElement modalContainer = driver.findElement(By.xpath("//div[contains(@class,'k-window k-dialog')]"));

                    // to fetch the web elements of the modal content and interact with them, code to fetch content of modal title and verify it
                    WebElement modalContentTitle = modalContainer.findElement(By.xpath("//span[contains(@class,'k-window-title k-dialog-title')]"));
                    Assert.assertEquals(modalContentTitle.getText(), "Delete standing order?", "Verify Title message");

                    WebEle = modalContainer.findElement(By.xpath(".//button/span[text()='Yes']"));
                    HelpersMethod.ActClick(driver, WebEle, 10000);

                    wait = new FluentWait<WebDriver>(driver)
                            .withTimeout(Duration.ofSeconds(600))
                            .pollingEvery(Duration.ofSeconds(2))
                            .ignoring(NoSuchElementException.class);
                    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

                    status = HelpersMethod.returnDocumentStatus(driver);
                    if (status.equals("loading"))
                    {
                        HelpersMethod.waitTillLoadingPage(driver);
                    }
                    scenario.log("STANDING ORDER DELETED");
                    exists = true;
                }
                //Thread.sleep(500);
                StandingOrders.remove(SO);
                //Thread.sleep(500);
                StandingOrders=HelpersMethod.FindByElements(driver,"xpath","//div[contains(@class,'standing-orders')]/descendant::span[contains(@class,'standing-orders-status active  ')]/ancestor::button|//div[contains(@class,'standing-orders')]/descendant::span[contains(@class,'standing-orders-status   pending')]/ancestor::button");
            }
            Assert.assertEquals(exists, true);
        }
        catch (Exception e){}
    }

    public void deleteExpiredSO() throws InterruptedException
    {
        WebElement WebEle;
        try
        {
            ClickOnNewStandingOrderArrow();
            HelpersMethod.ClickBut(driver,DeleteStandingOrder,10000);
            if(HelpersMethod.IsExists("//span[contains(text(),'Delete standing order?')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                WebElement modalContainer = driver.findElement(By.xpath("//div[contains(@class,'k-window k-dialog')]"));

                // to fetch the web elements of the modal content and interact with them, code to fetch content of modal title and verify it
                WebElement modalContentTitle = modalContainer.findElement(By.xpath(".//span[contains(@class,'k-window-title k-dialog-title')]"));
                Assert.assertEquals(modalContentTitle.getText(), "Delete standing order?", "Verify Title message");

                WebEle = modalContainer.findElement(By.xpath(".//button/span[text()='Yes']"));
                HelpersMethod.ActClick(driver, WebEle, 10000);
                scenario.log("EXPIRED STANDING ORDER DELETED");
                exists = true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void clickCopyStandingOrderButton()
    {
        try
        {
            exists = false;
            if (CopyStandingOrder.isDisplayed() && CopyStandingOrder.isEnabled())
            {
                HelpersMethod.ClickBut(driver, CopyStandingOrder, 10000);
                scenario.log("COPY STANDING ORDER HAS BEEN CLICKED");
                exists = true;
                HelpersMethod.WaitElementPresent(driver, "xpath", "//span[contains(text(),'Copy standing order')]/ancestor::div[contains(@class,'k-window k-dialog')]", 10000);
                new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Copy standing order')]/ancestor::div[contains(@class,'k-window k-dialog')]")));
            }
            Assert.assertEquals(exists, true);
        }
        catch (Exception e){}
    }

    public void validateVisiblilityOfCopyStandingOrderDiaglog()
    {
        exists = false;
        HelpersMethod.WaitElementPresent(driver, "xpath", "//span[contains(text(),'Copy standing order')]/ancestor::div[contains(@class,'k-window k-dialog')]", 400);
        HelpersMethod.waitTillElementLocatedDisplayed(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]", 10000);
        // to fetch the web element of the modal container
        WebElement modalContainer = driver.findElement(By.xpath("//div[contains(@class,'k-window k-dialog')]"));

        // to fetch the web elements of the modal content and interact with them, code to fetch content of modal title and verify it
        WebElement modalContentTitle = modalContainer.findElement(By.xpath(".//span[contains(@class,'k-window-title k-dialog-title')]"));
        Assert.assertEquals(modalContentTitle.getText(), "Copy standing order", "Verify Title message");
    }

    public void copyStandingOrderDialogForStartDate(int dStart) throws InterruptedException
    {
        String formattedDate1;
        WebElement WebEle;
        String FTDate;
        exists = false;

        HelpersMethod.waitTillElementLocatedDisplayed(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]", 1000);
        // to fetch the web element of the modal container
        WebElement modalContainer = driver.findElement(By.xpath("//div[contains(@class,'k-window k-dialog')]"));
        WebElement startDateIcon = modalContainer.findElement(By.xpath(".//input[@id='copyFromDate']/parent::span/following-sibling::button"));
        HelpersMethod.ActClick(driver, startDateIcon, 10000);
        new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']")));
        String status = HelpersMethod.returnDocumentStatus(driver);
        if (status.equals("loading"))
        {
            HelpersMethod.waitTillLoadingPage(driver);
        }
        new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']")));
        new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']"))));

        LocalDate myDateObj = LocalDate.now().plusDays(dStart);
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy");
        formattedDate1 = myDateObj.format(myFormatObj);

        // to fetch the web element of the modal container
        WebElement fromDateContainer = driver.findElement(By.xpath("//div[contains(@class,'k-calendar-view')]/descendant::table[@class='k-calendar-table']"));
        WebElement ele1 = fromDateContainer.findElement(By.xpath(".//td[contains(@title,'" + formattedDate1 + "')]/span"));
        HelpersMethod.JSScroll(driver, ele1);
        HelpersMethod.JScriptClick(driver, ele1, 10000);
        status = HelpersMethod.returnDocumentStatus(driver);
        if (status.equals("loading"))
        {
            HelpersMethod.waitTillLoadingPage(driver);
        }
        WebEle = HelpersMethod.FindByElement(driver, "id", "copyFromDate");
        FTDate = HelpersMethod.JSGetValueEle(driver, WebEle, 10000);
        scenario.log(FTDate + " HAS BEEN SELECTED AS START DATE FOR COPY STANDING ORDER");
        if (!FTDate.equals(null) && !FTDate.equals("MM/DD/YYYY"))
        {
            exists = true;
        }
        new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'k-calendar-monthview')]")));
        Assert.assertEquals(exists, true);
    }

    public void copyStandingOrderDialogForEndDate(int dEnd) throws InterruptedException
    {
        String formattedDate1;
        WebElement WebEle;
        String FTDate;
        exists = false;
        HelpersMethod.waitTillElementLocatedDisplayed(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]", 10000);

        String status = HelpersMethod.returnDocumentStatus(driver);
        if (status.equals("loading"))
        {
            HelpersMethod.waitTillLoadingPage(driver);
        }

      //  new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']")));
       // new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']"))));

        // to fetch the web element of the modal container
        WebElement modalContainer = driver.findElement(By.xpath("//div[contains(@class,'k-window k-dialog')]"));
        WebElement endDateIcon = modalContainer.findElement(By.xpath(".//input[@id='copyToDate']/parent::span/following-sibling::button"));
        HelpersMethod.JScriptClick(driver, endDateIcon, 10000);

        new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']")));
        status = HelpersMethod.returnDocumentStatus(driver);
        if (status.equals("loading"))
        {
            HelpersMethod.waitTillLoadingPage(driver);
        }
        new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='k-calendar-view k-vstack k-calendar-monthview']")));

        // to fetch the web element of the modal container
        WebElement ToDateContainer = driver.findElement(By.xpath("//div[contains(@class,'k-calendar-view')]/descendant::table[@class='k-calendar-table']"));

        LocalDate myDateObj = LocalDate.now().plusDays(dEnd);
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy");
        formattedDate1 = myDateObj.format(myFormatObj);
        WebElement ele1 = ToDateContainer.findElement(By.xpath(".//td[contains(@title,'" + formattedDate1 + "')]/span"));
        HelpersMethod.JSScroll(driver, ele1);
        HelpersMethod.JScriptClick(driver, ele1, 10000);
        status = HelpersMethod.returnDocumentStatus(driver);
        if (status.equals("loading"))
        {
            HelpersMethod.waitTillLoadingPage(driver);
        }
        WebEle = HelpersMethod.FindByElement(driver, "id", "copyToDate");
        FTDate = HelpersMethod.JSGetValueEle(driver, WebEle, 10000);
        scenario.log(FTDate + " HAS BEEN SELECTED AS END DATE FOR COPY STANDING ORDER");
        if (!FTDate.equals(null) && !FTDate.equals("MM/DD/YYYY"))
        {
            exists = true;
        }
        new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'k-calendar-monthview')]")));
    }

    public void copyButtonInCopyStandingOrderDiaglog()
    {
        exists = false;
        HelpersMethod.waitTillElementLocatedDisplayed(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]", 10000);
        // to fetch the web element of the modal container
        WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");

        //Click on Copy Button
        WebElement copyButton = modalContainer.findElement(By.xpath(".//button/span[text()='Copy']"));
        if (copyButton.isEnabled())
        {
            HelpersMethod.ClickBut(driver, copyButton, 10000);
            HelpersMethod.WaitElementPresent(driver,"xpath","//span[text()='Success']/ancestor::div[contains(@class,'k-window k-dialog')]",10000);
            exists = true;
        }
        Assert.assertEquals(exists, true);
    }

    public void copySuccessPopup()
    {
        try
        {
            exists = false;
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            //HelpersMethod.WaitElementPresent(driver, "xpath", "//span[text()='Success']/ancestor::div[contains(@class,'k-window k-dialog')]", 2000);
            //HelpersMethod.waitTillElementLocatedDisplayed(driver, "xpath", "//span[text()='Success']/ancestor::div[contains(@class,'k-window k-dialog')]", 4000);
            // to fetch the web element of the modal container
            WebElement copySuccessContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");
            // to fetch the web elements of the modal content and interact with them, code to fetch content of modal title and verify it
            WebElement successContentTitle = copySuccessContainer.findElement(By.xpath(".//span[contains(@class,'k-window-title k-dialog-title')]"));
            Assert.assertEquals(successContentTitle.getText(), "Success", "Verify Title message");

            //Click on Ok Button
            WebElement OkButton = HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]/descendant::button/span[text()='OK']");
            HelpersMethod.ActClick(driver, OkButton, 10000);
            exists = true;
            scenario.log("STANDING ORDER HAS BEEN COPIED SUCESSFULLY");
            Assert.assertEquals(exists, true);
        }
        catch (Exception e){}
    }

    public void clickOnStandingOrderRegisterButton()
    {
        exists=false;
        try
        {
            String status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            HelpersMethod.ClickBut(driver, ShowStandingOrder, 10000);
            exists = true;
            new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//div[contains(@class,'k-window k-dialog')]")));
            HelpersMethod.waitTillElementLocatedDisplayed(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]", 10000);
            status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            Assert.assertEquals(exists, true);
        }
        catch (Exception e){}
    }

    public void validateStandingOrderRegisterPopup()
    {
        try
        {
            String status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }

            HelpersMethod.waitTillElementLocatedDisplayed(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]", 200);
            // to fetch the web element of the modal container
            WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");

            // to fetch the web elements of the modal content and interact with them, code to fetch content of modal title and verify it
            WebElement modalContentTitle = modalContainer.findElement(By.xpath(".//span[contains(@class,'k-window-title k-dialog-title')]"));
            Assert.assertEquals(modalContentTitle.getText(), "Standing order register", "Verify Title message");
        }
        catch (Exception e){}
    }

    public void searchForCustomerAccountNo()
    {
        exists=false;
        try
        {
            if(HelpersMethod.IsExists("//span[contains(@class,'k-icon k-i-loading')]",driver))
            {
                new WebDriverWait(driver, Duration.ofMillis(100000)).until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[contains(@class,'k-icon k-i-loading')]")));
            }
            WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");
            WebElement custFilterInput = modalContainer.findElement(By.xpath(".//th[2]/div[@class='k-filtercell'][1]/descendant::input"));
            String Acc_No = TestBase.testEnvironment.get_Account();
            HelpersMethod.EnterText(driver, custFilterInput, 10000, Acc_No);
            exists = true;
            scenario.log("CUSTOMER ACCOUNT# ENTERED IS " + TestBase.testEnvironment.get_Account());
            String status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
        }
        catch (Exception e){}
    }

    public void clickOnCheckboxForCustomerAcc() throws InterruptedException
    {
        exists=false;
        try
        {
            WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");
            WebElement checkBoxCustomerAcc = modalContainer.findElement(By.xpath(".//tr[contains(@class,'k-master-row')]/descendant::input"));
            HelpersMethod.ActClick(driver, checkBoxCustomerAcc, 10000);
            exists = true;
            Assert.assertEquals(exists, true);
        }
        catch (Exception e){}
    }

    public void clickRemoveFilterForCustomerAcc() throws InterruptedException
    {
        exists=false;
        try
        {
            WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");
            WebElement custFilterButton = modalContainer.findElement(By.xpath(".//th[2]/div[@class='k-filtercell'][1]/descendant::button[@title='Clear']"));
            HelpersMethod.ActClick(driver, custFilterButton, 10000);
            exists = true;
            Assert.assertEquals(exists, true);
        }
        catch (Exception e){}
    }

    public void clickOnShowSelectedCustomerTaggle() throws InterruptedException
    {
        exists=false;

        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                .withTimeout(Duration.ofSeconds(600))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

        if(HelpersMethod.IsExists("//div[@id='standingOrderRegisterDialog']/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
        {
            WebElement custFilterButton = HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]/descendant::span[@id='selectedCustomersSwitch']");
            HelpersMethod.ActClick(driver, custFilterButton, 10000);
            exists = true;
        }
        Assert.assertEquals(exists,true);
    }

    public void navigateToRoute()
    {
        exists=false;
        try {
            Actions act1 = new Actions(driver);
            WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");
            List<WebElement> menus = modalContainer.findElements(By.xpath(".//div[contains(@class,'k-window-content k-dialog-content')]/descendant::ul/li/span"));
            for (WebElement menu : menus) {
                act1.moveToElement(menu).build().perform();
                String menu_Text = menu.getText();
                if (menu_Text.equals("Routes")) {
                    act1.moveToElement(menu).click().build().perform();
                    exists = true;
                    break;
                }
            }
        }
        catch (Exception e){}
    }

    public void searchForRoute()
    {
        exists = false;
        try
        {
            WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");
            WebElement custFilterInput = modalContainer.findElement(By.xpath(".//div[@class='k-animation-container k-animation-container-relative'][2]/descendant::table[1]/descendant::tr[@class='k-filter-row']/th[2]/div[@class='k-filtercell'][1]/descendant::input"));
            String route = TestBase.testEnvironment.get_Route1();
            HelpersMethod.EnterText(driver, custFilterInput, 10000, route);
            exists = true;
            String status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            Assert.assertEquals(exists, true);
        }
        catch (Exception e){}
    }

    public void clickOnCheckboxForRoute() throws InterruptedException
    {
        exists = false;
        try
        {
            WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");
            WebElement checkBoxRoute = modalContainer.findElement(By.xpath(".//div[@class='k-animation-container k-animation-container-relative'][2]/descendant::tr[contains(@class,'k-master-row')]/descendant::input"));
            HelpersMethod.ActClick(driver, checkBoxRoute, 10000);
            exists = true;
            Assert.assertEquals(exists, true);
        }
        catch (Exception e){}
    }

    public void clickRemoveFilterForRoute() throws InterruptedException
    {
        exists=false;
        try
        {
            WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");
            WebElement custFilterButton = modalContainer.findElement(By.xpath(".//div[@class='k-animation-container k-animation-container-relative'][2]/descendant::tr[@class='k-filter-row']/descendant::th[2]/div[@class='k-filtercell'][1]/descendant::button[@title='Clear']"));
            HelpersMethod.ActClick(driver, custFilterButton, 10000);
            exists = true;
            Assert.assertEquals(exists, true);
        }
        catch (Exception e){}
    }

    public void clickOnShowSelectedRouteTaggle() throws InterruptedException
    {
        exists = false;
        try
        {
            WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");
            WebElement custFilterButton = modalContainer.findElement(By.xpath(".//span[@id='selectedRoutesSwitch']"));
            HelpersMethod.ActClick(driver, custFilterButton, 10000);
            exists = true;
            Assert.assertEquals(exists, true);
        }
        catch (Exception e){}
    }

    public void clickOnStandingOrderCardExcel() throws InterruptedException
    {
        exists = false;
        try
        {
            WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");
            WebElement excelButton = modalContainer.findElement(By.xpath(".//button[@id='standingOrderRegisterDialogExcelButton']"));
            HelpersMethod.ActClick(driver, excelButton, 10000);
            exists = true;
            String status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            if (HelpersMethod.IsExists("//div[@id='toast-container']", driver))
            {
                scenario.log("NO DATA HAS BEEN GENERATED");
                Thread.sleep(2000);
            }
            else
            {
                scenario.log(".csv FILE DOWNLOADED");
            }
            WebElement cancelButton = modalContainer.findElement(By.xpath(".//button[@id='standingOrderRegisterDialogCancelButton']"));
            HelpersMethod.ClickBut(driver, cancelButton, 10000);
            Thread.sleep(6000);
            Assert.assertEquals(exists, true);
        }
        catch (Exception e){}
    }

    public void clickOnStandingOrderCardPdf() throws InterruptedException
    {
        try
        {
            exists = false;
            String ParentWindow = driver.getWindowHandle();
            WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");
            WebElement pdfButton = modalContainer.findElement(By.xpath(".//button[@id='standingOrderRegisterDialogPDFButton']"));
            HelpersMethod.ActClick(driver, pdfButton, 10000);
            String status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            Thread.sleep(2000);
            if (HelpersMethod.IsExists("//div[@id='toast-container']", driver))
            {
                scenario.log("<span style='color:red'>NO DATA HAS BEEN GENERATED</span>");
                exists=true;
                Thread.sleep(3000);
            }
            else
            {
                Set<String> PCWindows = driver.getWindowHandles();
                for (String PCwind : PCWindows)
                {
                    if (!PCwind.equals(ParentWindow))
                    {
                        driver.switchTo().window(PCwind);
                        scenario.log(".pdf HAS BEEN FOUND");
                        driver.close();
                        exists = true;
                        scenario.log("STANDING ORDER REGISTER HAS BEEN HANDLED");
                    }
                }
                driver.switchTo().window(ParentWindow);
            }
            //Click on Cancel button
            WebElement cancelButton = modalContainer.findElement(By.xpath(".//button[@id='standingOrderRegisterDialogCancelButton']"));
            HelpersMethod.ClickBut(driver, cancelButton, 10000);
            Assert.assertEquals(exists, true);
        }
        catch ( Exception e){}
    }

    public void clickOnGenerateStandingOrder()
    {
        exists=false;
        try
        {
            String status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            if (GenerateStandingOrder.isDisplayed() && GenerateStandingOrder.isEnabled())
            {
                HelpersMethod.ScrollElement(driver,GenerateStandingOrder);
                HelpersMethod.ClickBut(driver, GenerateStandingOrder, 10000);
                scenario.log("GENERATE STANDING ORDER HAS BEEN CLICKED");
                exists = true;
            }
            status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            Assert.assertEquals(exists, true);
        }
        catch (Exception e){}
    }

    public void verifyGenerateStandingOrderPopup() throws InterruptedException
    {
        Thread.sleep(1000);
        exists=false;
        try
        {
            if(HelpersMethod.IsExists("//span[contains(text(),'Generate standing order')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void clickOnStartStandingOrderCalender()
    {
        try
        {
            // to fetch the web element of the modal container
            WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");
            //Identify From calender and click
            WebElement fromCalender = modalContainer.findElement(By.xpath(".//label[contains(text(),'From date')]/following-sibling::span/descendant::button"));
            HelpersMethod.JScriptClick(driver, fromCalender, 10000);
            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//div[contains(@class,'k-widget k-calendar k-calendar-range')]")));
            new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'k-widget k-calendar k-calendar-range')]")));
        }
        catch (Exception e){}
    }

    public void selectFromDateForGenerateSO()
    {
        exists=false;
        try
        {
            if(HelpersMethod.IsExists("//div[@class='k-animation-container k-animation-container-shown']",driver))
            {
                WebElement selectableDate = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='k-calendar k-calendar-range k-calendar-md']/descendant::table[1]/descendant::td[@class='k-calendar-td k-range-end k-selected']/span");
                HelpersMethod.ActClick(driver,selectableDate,10000);
                new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='k-animation-container k-animation-container-shown']")));
                exists = true;
            }
            Assert.assertEquals(exists,true);
        }
        catch ( Exception e){}
    }

    public void clickToDateForGenerateSO()
    {
        exists=false;
        Actions act1 = new Actions(driver);
        try
        {
            if(HelpersMethod.IsExists("//span[contains(text(),'Generate standing order')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                // to fetch the web element of the modal container
                WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");
                //First click on input box of ToDate in dialog box
                WebElement toDateInput=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]/descendant::input[2]");

                act1.moveToElement(toDateInput).click().build().perform();
                //Identify To calender and click
                WebElement toCalender = modalContainer.findElement(By.xpath(".//label[contains(text(),'To date')]/following-sibling::span/descendant::button"));
                HelpersMethod.JScriptClick(driver, toCalender, 10000);
                exists=true;
                new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//div[contains(@class,'k-widget k-calendar k-calendar-range')]")));
                new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'k-widget k-calendar k-calendar-range')]")));
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e) {}
    }

    public void selectToDateForGenerateSO()
    {
        try
        {
            exists=false;
            Actions act=new Actions(driver);
            String toDateText;
            if(HelpersMethod.IsExists("//div[@class='k-animation-container k-animation-container-shown']",driver))
            {
//                WebElement toDate = HelpersMethod.FindByElement(driver, "xpath", "//div[@class='k-calendar k-calendar-range k-calendar-md']/descendant::td[contains(@class,'k-selected')]/span");
//                HelpersMethod.ActClick(driver,toDate,10000);
                List<WebElement> toDates=HelpersMethod.FindByElements(driver,"xpath","//div[@class='k-calendar k-calendar-range k-calendar-md']/descendant::td[contains(@style,'opacity: 1')]");
                for(WebElement toDate:toDates)
                {
                   act.moveToElement(toDate).build().perform();
                   toDateText= HelpersMethod.AttributeValue(toDate,"title");
                       if(toDateText.contains(daysText.get(0)))
                       {
                           WebElement toDateToSelect=HelpersMethod.FindByElement(driver,"xpath","//div[@class='k-calendar k-calendar-range k-calendar-md']/descendant::td[contains(@style,'opacity: 1') and contains(@title,'"+toDateText+"')]/span");
                           act.moveToElement(toDateToSelect).click().build().perform();
                           break;
                       }
                }
                exists = true;
            }
            Assert.assertEquals(exists,true);
        }
        catch(Exception e){}
    }

    public String readFromDateForGenerateSO()
    {
        exists=true;
        try
        {
            WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");
            WebElement fromDateInput=modalContainer.findElement(By.xpath(".//input[1]"));
            fromGenerateDate= HelpersMethod.getAttributeValue(driver,fromDateInput,10000);
            scenario.log("FROM DATE FOR GENERATE REPORT "+fromGenerateDate);
            if(!fromGenerateDate.equals("")||fromGenerateDate==null)
            {
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
        return fromGenerateDate;
    }
    public void readToDateForGenerateSO()
    {
        exists=true;
        try
        {
            WebElement toDateInput=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]/descendant::input[2]");
            toGenerateDate= HelpersMethod.getAttributeValue(driver,toDateInput,10000);
            scenario.log("TO DATE FOR GENERATE REPORT "+toGenerateDate);
            if(!toGenerateDate.equals("")||toGenerateDate==null)
            {
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void clickOnOkButtonInGenerateSO() throws InterruptedException
    {
        exists=false;
        try
        {
            new WebDriverWait(driver,Duration.ofMillis(2000)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Generate standing order')]/ancestor::div[contains(@class,'k-window k-dialog')]")));
            new WebDriverWait(driver,Duration.ofMillis(2000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Generate standing order')]/ancestor::div[contains(@class,'k-window k-dialog')]")));
            if(HelpersMethod.IsExists("//span[contains(text(),'Generate standing order')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                WebElement OkCalender = HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]/descendant::button/span[text()='Ok']");
                HelpersMethod.ActClick(driver, OkCalender, 20000);
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void validateGeneratingStandingOrdersForCustomersPopup()
    {
        if(HelpersMethod.IsExists("//div[contains(text(),'Generating standing orders for customers.')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
        {
            WebElement modalContainer = driver.findElement(By.xpath("//div[contains(@class,'k-window k-dialog')]"));

            // to fetch the web elements of the modal content and interact with them, code to fetch content of modal title and verify it
            WebElement modalContentTitle = modalContainer.findElement(By.xpath(".//span[contains(@class,'k-window-title k-dialog-title')]"));
            Assert.assertEquals(modalContentTitle.getText(), "Generate standing order(s)", "Verify Title message");
        }
    }

    public void waitTillGeneratingStandingOrdersForCustomersDisappears()
    {
        exists=false;
        try
        {
            if (HelpersMethod.IsExists("//div[contains(text(),'Generating standing orders for customers.')]/ancestor::div[contains(@class,'k-window k-dialog')]", driver))
            {
                new WebDriverWait(driver, Duration.ofMillis(200000)).until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'k-window k-dialog')]")));
                scenario.log("FOUND GENERATING ORDER FOR CUSTOMER");
            }
            //Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void validateAllTasksCompletedPopup()
    {
        try
        {
            if (HelpersMethod.IsExists("//div[contains(text(),'All tasks completed. Error count:')]/ancestor::div[contains(@class,'k-window k-dialog')]", driver)) {
                WebElement modalContainer = driver.findElement(By.xpath("//div[contains(@class,'k-window k-dialog')]"));

                // to fetch the web elements of the modal content and interact with them, code to fetch content of modal title and verify it
                WebElement modalContentTitle = modalContainer.findElement(By.xpath(".//span[contains(@class,'k-window-title k-dialog-title')]"));
                Assert.assertEquals(modalContentTitle.getText(), "Generate standing order(s)", "Verify Title message");
            }
        }
        catch (Exception e){}
    }

    public void clickOnViewDetails()
    {
        try
        {
            WebElement modalContainer = driver.findElement(By.xpath("//div[contains(@class,'k-window k-dialog')]"));
            //creating webelement for view details button
            WebElement viewDetailsButton = modalContainer.findElement(By.xpath(".//button[contains(text(),'View details')]"));
            if (viewDetailsButton.isEnabled())
            {
                HelpersMethod.ActClick(driver, viewDetailsButton, 10000);
            }
            else
            {
                scenario.log("VIEW DETAILS BUTTON IS NOT ENABLED, MAY BE NOT ABLE TO GENERATE THE REPORT PLZ CHECK THE DATE RANGE");
            }
        }
        catch (Exception e){}
    }

    public void clickOnOkGenerateStandingOrder()
    {
        exists=false;
        try
        {
            if(HelpersMethod.IsExists("//div[contains(@class,'k-window k-dialog')]/descendant::button/span[text()='Ok']",driver))
            {
                WebElement modalContainer = driver.findElement(By.xpath("//div[contains(@class,'k-window k-dialog')]"));
                //creating webelement for view details button
                WebElement okButton = modalContainer.findElement(By.xpath(".//button/span[text()='Ok']"));
                HelpersMethod.ClickBut(driver, okButton, 10000);
            }
        }
        catch (Exception e){}
    }

    public void clickOnOkInAllTasksCompleted()
    {
        try
        {
            if(HelpersMethod.IsExists("//span[contains(text(),'Generate standing order(s)')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                WebElement modalContainer = driver.findElement(By.xpath("//div[contains(@class,'k-window k-dialog')]"));
                //creating webelement for view details button
                WebElement okButton = modalContainer.findElement(By.xpath(".//button/span[text()='Ok']"));
                HelpersMethod.ClickBut(driver, okButton, 10000);
            }
        }
        catch (Exception e){}
    }

    public void standingOrderCancelButton()
    {
        exists=false;
        WebElement WebEle;
        try
        {
            if(HelpersMethod.IsExists("//button[@id='standingOrderRegisterDialogCancelButton']",driver))
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//button[@id='standingOrderRegisterDialogCancelButton']");
                HelpersMethod.ClickBut(driver,WebEle,10000);
                exists=true;
                Thread.sleep(2000);
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public List<WebElement> readDatesOfStandingOrder()
    {
        exists=false;
        List<WebElement> soDate = null;
        try
        {
            List<WebElement> StandingOrders = HelpersMethod.FindByElements(driver, "xpath", "//div[contains(@class,'standing-orders')]/descendant::span[contains(@class,'standing-orders-status active')] | //div[contains(@class,'standing-orders')]/descendant::span[contains(@class,'standing-orders-status pending')]");
            scenario.log("TOTAL ACTIVE AND PENDING STANDING ORDERS FOUND ARE "+StandingOrders.size());
            soDate=HelpersMethod.FindByElements(driver,"xpath","//div[contains(@class,'standing-orders')]/descendant::span[contains(@class,'standing-orders-status active')]/following-sibling::div[2] | //div[contains(@class,'standing-orders')]/descendant::span[contains(@class,'standing-orders-status pending')]/following-sibling::div[2]");
        }
        catch (Exception e){}
        return soDate;
    }

    public void selectExpiredSO()
    {
        exists=false;
        try
        {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
            if(HelpersMethod.IsExists("//span[@class='k-icon k-i-arrow-chevron-down']",driver))
            {
                WebElement arrowDown=HelpersMethod.FindByElement(driver,"xpath","//span[@class='k-icon k-i-arrow-chevron-down']");
                HelpersMethod.ActClick(driver,arrowDown,10000);
            }

            if(HelpersMethod.IsExists("//div[@class='standing-orders']/descendant::span[contains(@class,'standing-orders-status  expired ')][1]/ancestor::button",driver))
            {
                WebElement expiredSO=HelpersMethod.FindByElement(driver,"xpath","//div[@class='standing-orders']/descendant::span[contains(@class,'standing-orders-status  expired ')][1]/ancestor::button");
                HelpersMethod.ActClick(driver,expiredSO,50000);
                exists=true;
            }
            else
            {
                scenario.log("NO EXPIRED STANDING ORDER HAS BEEN FOUND");
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void validateFromStandingOrderCalender()
    {
        exists=false;
        try
        {
            Thread.sleep(500);
            if(HelpersMethod.IsExists("//div[contains(@class,'k-animation-container k-animation-container-shown')]",driver))
            {
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void validateToStandingOrderCalender()
    {
        exists=false;
        try
        {
            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'k-animation-container k-animation-container-shown')]"))));
            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'k-animation-container k-animation-container-shown')]")));
            if(HelpersMethod.IsExists("//div[contains(@class,'k-animation-container k-animation-container-shown')]",driver))
            {
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void validateDialogboxSOAllreadyExists()
    {
        exists=false;
        try
        {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            String status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }

            if(HelpersMethod.IsExists("//div[contains(text(),'Standing order exist for the selected date.')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                WebElement modelContainer=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]");
                WebElement okButton=modelContainer.findElement(By.xpath(".//button/span[text()='OK']"));
                HelpersMethod.ActClick(driver,okButton,10000);
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void cancelAddSO()
    {
        exists=false;
        try
        {
            if(HelpersMethod.IsExists("//span[contains(text(),'Add standing order')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                WebElement modelContainer=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]");
                WebElement cancelButton=modelContainer.findElement(By.xpath(".//button/span[text()='Cancel']"));
                HelpersMethod.ActClick(driver,cancelButton,10000);
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void readEnabledDaysInGrid()
    {
        Actions act=new Actions(driver);
        String dayEnableText;
        try
        {
           List<WebElement> daysEnabled=HelpersMethod.FindByElements(driver,"xpath","//div[@class='grid-container']/descendant::a[@id='k-link-editable']");
           for(WebElement dayElement:daysEnabled)
           {
              act.moveToElement(dayElement).build().perform();
              dayEnableText=dayElement.getText();
              daysText.add(dayEnableText);
           }
        }
        catch (Exception e){}
    }
}