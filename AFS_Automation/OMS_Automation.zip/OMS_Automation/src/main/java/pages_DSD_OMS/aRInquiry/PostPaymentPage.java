package pages_DSD_OMS.aRInquiry;

import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.testng.Assert;
import util.RandomValues;

import java.util.List;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class PostPaymentPage
{
    /* Created by Divya.Ramadas@afsi.com */
    WebDriver driver;
    Scenario scenario;
    static boolean exists=false;

    @FindBy(id="newPayment")
    private WebElement AddPayment;

    @FindBy(xpath="//button/span[text()='Post']")
    private WebElement PostBut;

    @FindBy(id="cancelBtn")
    private WebElement CancelBut;

    public PostPaymentPage(WebDriver driver,Scenario scenario)
    {
        this.driver=driver;
        this.scenario=scenario;
        PageFactory.initElements(new AjaxElementLocatorFactory(driver,40),this);
    }

    //actions
    public void ValidatePostPayment()
    {
        exists=false;
        WebElement WebEle;
        String PageTitle;
        try
        {
            WebEle=HelpersMethod.FindByElement(driver,"xpath","//span[@class='spnmoduleNameHeader']");
            PageTitle=WebEle.getText();
            Assert.assertEquals(PageTitle,"Post payment");
        }
        catch (Exception e){}
    }

    public void SelectPayment()
    {
        exists = false;
        WebElement WebEle;
        try {
            if (HelpersMethod.IsExists("//div[contains(@class,'payment-method-container')]/descendant::tbody/tr[2]/descendant::input", driver))
            {
                WebEle = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'payment-method-container')]/descendant::tbody/tr[2]/descendant::input");
                HelpersMethod.ClickBut(driver, WebEle, 1000);
                exists = true;
            }
            else
            {
                scenario.log("NOT FOUND ANY PAYMENT METHODS");
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e) {}
    }

    public void Click_PostBut()
    {
        exists=false;
        WebElement WebEle;
        try
        {
            HelpersMethod.ClickBut(driver,PostBut,1000);
            if(HelpersMethod.IsExists("//div[@class='loader']",driver))
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 100000);
            }
            if(HelpersMethod.IsExists("//div[contains(text(),'Thank you')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]/descendant::button");
                HelpersMethod.ClickBut(driver,WebEle,1000);
            }
            exists=true;
        }
        catch (Exception e){}
    }

    public void CancelButton()
    {
        exists=false;
        try
        {
            HelpersMethod.ClickBut(driver,CancelBut,1000);
            exists=true;
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void cancelPopup()
    {
        try
        {
            if(HelpersMethod.IsExists("//div[contains(@class,'k-window k-dialog')]",driver))
            {
                WebElement modalContainer = HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]");

                WebElement modalContentTitle = modalContainer.findElement(By.xpath(".//span[contains(@class,'k-window-title k-dialog-title')]"));
                Assert.assertEquals(modalContentTitle.getText(), "Discard payment", "Verify Title message");

                WebElement button=modalContainer.findElement(By.xpath(".//button/span[text()='Yes']"));
                HelpersMethod.ClickBut(driver,button,1000);
            }
        }
        catch(Exception e){}
    }

    public void AddNewPayment()
    {
        exists=false;
        try
        {
            HelpersMethod.ClickBut(driver,AddPayment,1000);
            exists=true;
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void ValidateAddingPaymentDetails()
    {
        exists=false;
        try
        {
            if(HelpersMethod.IsExists("//div[contains(text(),'New payment method')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void PaymentType()
    {
        exists=false;
        try
        {
            WebElement PaymentDropDown=HelpersMethod.FindByElement(driver,"id","PaymentType");
            HelpersMethod.ClickBut(driver,PaymentDropDown,1000);
            exists=true;
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void PaymentDropDown(String PayType)
    {
        exists=false;
        try
        {
            HelpersMethod.DropDownMenu_withOutScrollbar(driver,PayType);
            exists=true;
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void EnterFirstName(String FName)
    {
        exists=false;
        WebElement FirstName=HelpersMethod.FindByElement(driver,"id","FirstName");
        try
        {
            if(FirstName.isDisplayed() && FirstName.isEnabled())
            {
                HelpersMethod.EnterText(driver,FirstName,1000,FName);
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void EnterLastName(String LName)
    {
        exists=false;
        WebElement LastName=HelpersMethod.FindByElement(driver,"id","LastName");
        try
        {
            if(LastName.isDisplayed() && LastName.isEnabled())
            {
                HelpersMethod.EnterText(driver,LastName,1000,LName);
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void Click_AccType()
    {
        exists=false;
        WebElement BankAccType=HelpersMethod.FindByElement(driver,"id","BAAccountType");
        try
        {
            if(BankAccType.isDisplayed() && BankAccType.isEnabled())
            {
                HelpersMethod.ClickBut(driver,BankAccType,1000);
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void Select_AccType(String AcType)
    {
        exists=false;
        try
        {
            List<WebElement> AccTypes=HelpersMethod.FindByElements(driver,"xpath","//div[contains(@class,'k-list-scroller')]/ul/li");
            HelpersMethod.ActClick(driver,AccTypes.get(1),1000);
            exists=true;
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void Enter_Route()
    {
        exists=false;
        WebElement RouteNo=HelpersMethod.FindByElement(driver,"id","BARoutingNumber");
        try
        {
            HelpersMethod.EnterText(driver,RouteNo,1000, RandomValues.generateRandomAlphaNumeric(5));
            exists=true;
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void Enter_AccountNo()
    {
        exists=false;
        WebElement BankNo=HelpersMethod.FindByElement(driver,"id","BAAccountNumber");
        try
        {
            HelpersMethod.EnterText(driver,BankNo,1000, RandomValues.generateRandomNumber(10));
            exists=true;
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void SetPreferenceCheckbox()
    {
        exists=false;
        WebElement SetPrefer=HelpersMethod.FindByElement(driver,"id","IsPreferred");
        try
        {
            HelpersMethod.ClickBut(driver,SetPrefer,1000);
            exists=true;
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void NewPaymentOkBut()
    {
        exists=false;
        WebElement WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]/descendant::.//button/span[text()='Continue']");
        try
        {
            HelpersMethod.ClickBut(driver,WebEle,1000);
            exists=true;
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }
}