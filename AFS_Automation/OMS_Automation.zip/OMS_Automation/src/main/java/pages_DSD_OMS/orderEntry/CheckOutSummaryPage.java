package pages_DSD_OMS.orderEntry;

import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import org.apache.logging.log4j.core.tools.picocli.CommandLine;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import util.TestBase;

import java.awt.*;
import java.time.Duration;
import java.util.*;
import java.util.List;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class CheckOutSummaryPage
{
    /* Created by Divya */
    WebDriver driver;
    Scenario scenario;
    static String Order_No;
    static String Quote_No;
    static boolean exists=false;

    @FindBy(id = "ConfirmSummaryButton")
    private WebElement Submit_But;

    @FindBy(id="CancelSummaryButton")
    private WebElement Cancel_But;

    @FindBy(id="OrdersButton")
    private  WebElement BackOrder;

    @FindBy(id="CommentsButton")
    private WebElement Comment_But;

    @FindBy(id="EditButton")
    private WebElement Edit_But;

    @FindBy(id="PrintButton")
    private  WebElement PrintBut;

    @FindBy(id="CopyOrderButton_sbc")
    private WebElement CopyBut;

    @FindBy(xpath = "//div[contains(@class,'order-number-item-container')]/descendant::div[@class='item-value']")
    private  WebElement Ord;

    @FindBy(xpath = "//div[contains(text(),'Product total')]/following-sibling::div")
    private  WebElement TotAmt;

    @FindBy(id="CancelSummaryButton")
    private WebElement CancelBut;

    @FindBy(xpath = "//span[@class='k-chip-action k-chip-remove-action']")
    private WebElement Button_Close;

    @FindBy(xpath="//div[contains(@class,'k-grouping-header')]/descendant::div[contains(@class,'k-grouping-drop-container')]")
    private WebElement To;

    public CheckOutSummaryPage(WebDriver driver,Scenario scenario) throws InterruptedException, AWTException
    {
        this.scenario=scenario;
        this.driver =driver;
        PageFactory.initElements(driver,this);
    }

    //Actions
    public void validateSummaryPage()
    {
        exists=false;
        try
        {
            Wait<WebDriver> wait = new FluentWait<>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            String status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }

           wait = new FluentWait<>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }

            wait = new FluentWait<>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            if(HelpersMethod.IsExists("//div[contains(@class,'checkout-summary-content')]",driver))
            {
                scenario.log("ORDER ENTRY SUMMARY PAGE HAS BEEN FOUND");
                exists=true;
            }
            wait = new FluentWait<>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void FindtableHeader(String To_Text)
    {
        exists=false;
        Actions act=new Actions(driver);
        try
        {
            WebElement OEProdGrid=HelpersMethod.FindByElement(driver,"id","orderEntryGridContainer");
            HelpersMethod.ScrollElement(driver,OEProdGrid);
            if(HelpersMethod.IsExists("//div[contains(@class,'k-grouping-header')]/descendant::div[contains(@class,'k-grouping-drop-container')]",driver))
            {
                List<WebElement> TableHeads=driver.findElements(By.xpath("//thead/tr[1]/th/descendant::span[@class='k-column-title']"));
                for(WebElement THead:TableHeads)
                {
                    String Head=THead.getText();
                    if(Head.contains(To_Text))
                    {
                        HelpersMethod.ActDragDrop(driver,THead,To);
                        exists=true;
                    }
                }
            }
            else
            {
                scenario.log("DRAG AND DROP HEADER MAY NOT BE ENABLED, CHECK ADMIN SETTINGS");
            }
            List<WebElement> groups=HelpersMethod.FindByElements(driver,"xpath","//tr[@class='k-grouping-row']/descendant::p");
            for (WebElement group:groups)
            {
                act.moveToElement(group).build().perform();
                String group_Text=group.getText();
                scenario.log("GROUP VALUE FOUND IS "+group_Text);
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public String Find_TotalAmt()
    {
        String Tot=null;
        try
        {
            HelpersMethod.ScrollElement(driver,TotAmt);
            Tot= HelpersMethod.ReadValue(TotAmt);
            scenario.log("TOTAL ORDER AMOUNT IS "+Tot);
        }
        catch (Exception e){}
        return  Tot;
    }

    public void ClickSubmit() throws InterruptedException
    {
        exists=false;
        Wait<WebDriver> wait;

        String status = HelpersMethod.returnDocumentStatus(driver);
        if (status.equals("loading"))
        {
            HelpersMethod.waitTillLoadingPage(driver);
        }
        wait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(600))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

        status = HelpersMethod.returnDocumentStatus(driver);
        if (status.equals("loading"))
        {
            HelpersMethod.waitTillLoadingPage(driver);
        }

        wait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(600))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

        status = HelpersMethod.returnDocumentStatus(driver);
        if (status.equals("loading"))
        {
            HelpersMethod.waitTillLoadingPage(driver);
        }
        HelpersMethod.ScrollUpScrollBar(driver);
        if(HelpersMethod.IsExists("//button[@id='ConfirmSummaryButton']",driver))
        {
            WebElement submitButton = HelpersMethod.FindByElement(driver, "xpath", "//button[@id='ConfirmSummaryButton']");
            HelpersMethod.ScrollUpScrollBar(driver);
            HelpersMethod.ActClick(driver,submitButton,40000);
            scenario.log("SUBMIT BUTTON IN ORDER SUMMARY PAGE HAS BEEN CLICKED");

            wait = new FluentWait<>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            exists=true;
        }
        else if(HelpersMethod.IsExists("//button[@id='ConfirmSummarySplitButton']",driver))
        {
            WebElement submitButton = HelpersMethod.FindByElement(driver, "xpath", "//button[@id='ConfirmSummarySplitButton']");
            HelpersMethod.ScrollUpScrollBar(driver);
            HelpersMethod.ActClick(driver,submitButton,40000);
            scenario.log("SUBMIT BUTTON IN ORDER SUMMARY PAGE HAS BEEN CLICKED");

            wait = new FluentWait<>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            exists=true;
        }
        else if(HelpersMethod.IsExists("//button[@id='ConfirmSummarySplitButton_dropdown']",driver))
        {
            //Click on Arrow button next to submit button
            WebElement submitCutOff=HelpersMethod.FindByElement(driver,"xpath","//button[@id='ConfirmSummarySplitButton_dropdown']/following-sibling::div/button/span");
            HelpersMethod.ActClick(driver,submitCutOff,20000);

            new WebDriverWait(driver,Duration.ofMillis(40000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'k-child-animation-container')]/descendant::ul/li")));
            //Click on list that appears
            WebElement arrowCutoff=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-child-animation-container')]/descendant::ul/li");
            HelpersMethod.ActClick(driver,arrowCutoff,40000);
            scenario.log("SUBMIT BUTTON IN ORDER SUMMARY PAGE HAS BEEN CLICKED");
            wait = new FluentWait<>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
            exists=true;
        }

        Assert.assertEquals(exists,true);
    }

    public void additionalOrderPopup()
    {
        try
        {
            Thread.sleep(2000);

            String status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }

            Wait<WebDriver> wait = new FluentWait<>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }

            wait = new FluentWait<>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            if(HelpersMethod.IsExists("//div[contains(text(),'Additional order(s) have been found')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                WebElement additionalPopup=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]");
                WebElement yesButton=additionalPopup.findElement(By.xpath(".//button/span[text()='Yes']"));
                HelpersMethod.ClickBut(driver,yesButton,20000);
                if(HelpersMethod.IsExists("//div[contains(@class,'k-notification-error')]|//div[contains(@class,'k-notification-success')]",driver))
                {
                    exists=true;
                    scenario.log("<span style='color:red'>ERROR MESSAGE HAS BEEN FOUND IN ORDER ENTRY PAGE</span>");
                    Assert.assertEquals(exists,true);
                }
            }
        }
        catch (Exception e){}
    }

    public void cutoffDialog()
    {
        try
        {
            Thread.sleep(1000);
            Wait<WebDriver> wait = new FluentWait<>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            for(int i=0;i<=2;i++)
            {
                if (HelpersMethod.IsExists("//div[contains(text(),'Attention: Although the cutoff time has been reached')]/ancestor::div[contains(@class,'k-window k-dialog')]", driver))
                {

                    wait = new FluentWait<WebDriver>(driver)
                            .withTimeout(Duration.ofSeconds(600))
                            .pollingEvery(Duration.ofSeconds(2))
                            .ignoring(org.openqa.selenium.NoSuchElementException.class);
                    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

                    new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'k-window k-dialog')]/descendant::button/span[text()='Continue']"))));
                    new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'k-window k-dialog')]/descendant::button/span[text()='Continue']"))));

                    WebElement dialogBox = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");
                    WebElement continueBut = dialogBox.findElement(By.xpath(".//button/span[contains(text(),'Continue')]"));
                    HelpersMethod.ActClick(driver, continueBut, 10000);
                    scenario.log("ORDER CUTOFF DIALOG BOX HAS BEEN HANDLED");
                    wait = new FluentWait<>(driver)
                            .withTimeout(Duration.ofSeconds(600))
                            .pollingEvery(Duration.ofSeconds(2))
                            .ignoring(NoSuchElementException.class);
                    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
                }
                if (HelpersMethod.IsExists("//div[contains(text(),'% of your average order for the given products:')]/ancestor::div[contains(@class,'k-window k-dialog')]", driver))
                {

                   wait = new FluentWait<WebDriver>(driver)
                            .withTimeout(Duration.ofSeconds(600))
                            .pollingEvery(Duration.ofSeconds(2))
                            .ignoring(org.openqa.selenium.NoSuchElementException.class);
                    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

                    WebElement percentagePopup = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");
                    WebElement continueButton = percentagePopup.findElement(By.xpath(".//button/span[text()='Continue']"));
                    HelpersMethod.ActClick(driver, continueButton, 10000);
                    scenario.log("% POPUP HAS BEEN HANDLED");

                    wait = new FluentWait<>(driver)
                            .withTimeout(Duration.ofSeconds(600))
                            .pollingEvery(Duration.ofSeconds(2))
                            .ignoring(NoSuchElementException.class);
                    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
                }
            }

            wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(org.openqa.selenium.NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
        }
        catch (Exception e){}
    }

    public void SucessPopup()
    {
        String status;
        try
        {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            if (HelpersMethod.IsExists("//div[contains(text(),'Order submitted successfully.')]/ancestor::div[contains(@class,'k-window k-dialog')]", driver))
            {
                // to fetch the web element of the modal container
                WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]");

                //Click on OK button in "Success popup"
                new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.elementToBeClickable(By.xpath("//button/span[text()='Ok']")));
                WebElement OK_But = modalContainer.findElement(By.xpath(".//button/span[text()='Ok']"));
                HelpersMethod.ClickBut(driver, OK_But, 10000);

                scenario.log("ORDER HAS BEEN SUCESSFULLY CREATED");
                status = HelpersMethod.returnDocumentStatus(driver);
                if (status.equals("loading"))
                {
                    HelpersMethod.waitTillLoadingPage(driver);
                }
                wait = new FluentWait<>(driver)
                        .withTimeout(Duration.ofSeconds(600))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
                status = HelpersMethod.returnDocumentStatus(driver);
                if (status.equals("loading"))
                {
                    HelpersMethod.waitTillLoadingPage(driver);
                }
            }
        }
        catch (Exception e){}
    }

    public void SucessPopupForAllOrder()
    {
        String status;
        status = HelpersMethod.returnDocumentStatus(driver);
        if (status.equals("loading"))
        {
            HelpersMethod.waitTillLoadingPage(driver);
        }

        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                .withTimeout(Duration.ofSeconds(600))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

        status = HelpersMethod.returnDocumentStatus(driver);
        if (status.equals("loading"))
        {
            HelpersMethod.waitTillLoadingPage(driver);
        }
        wait = new FluentWait<WebDriver>(driver)
                .withTimeout(Duration.ofSeconds(600))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

        if(HelpersMethod.IsExists("//div[contains(text(),'Order submitted successfully.')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
        {
            // to fetch the web element of the modal container
            WebElement modalContainer = HelpersMethod.FindByElement(driver, "xpath", "//div[contains(text(),'Order submitted successfully.')]/ancestor::div[contains(@class,'k-window k-dialog')]");
            //Click on OK button in "Success popup"
            WebElement OK_But = modalContainer.findElement(By.xpath(".//button/span[text()='Ok']"));
            HelpersMethod.ClickBut(driver, OK_But, 10000);

            scenario.log("ORDER HAS BEEN SUCCESSFULLY CREATED");
            status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
            status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
        }
    }

   public String Get_Order_No()
    {
        WebElement WebEle;
        String status;
        try
        {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }

            wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'order-number-item-container')]");
            HelpersMethod.ScrollElement(driver,WebEle);
            Order_No = HelpersMethod.ReadValue(Ord);
            scenario.log("ORDER CRATED, ORDER # IS "+Order_No);
        }
        catch (Exception e){}
        return Order_No;
    }

    public String Get_Quote_No()
    {
        WebElement WebEle;
        try
        {
            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'order-number-item-container')]");
            HelpersMethod.ScrollElement(driver,WebEle);
            Quote_No = HelpersMethod.ReadValue(Ord);
            scenario.log("QUOTE IS CRATED, QUOTE # IS "+Quote_No);
        }
        catch (Exception e){}
        return Quote_No;
    }

    public void Click_Edit()
    {
        exists=false;
        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                .withTimeout(Duration.ofSeconds(600))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
        try
        {
            if (Edit_But.isDisplayed() && Edit_But.isEnabled())
            {
                Thread.sleep(1000);
                Edit_But=HelpersMethod.FindByElement(driver,"id","EditButton");
                HelpersMethod.ScrollElement(driver,Edit_But);
                HelpersMethod.ActClick(driver,Edit_But,10000);
                exists=true;
                wait = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(600))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
            }
            Assert.assertTrue(exists);
        }
        catch (Exception e){}
    }
    public void Click_copy()
    {
        exists=false;
        try
        {
            Thread.sleep(1000);
            if (CopyBut.isEnabled())
            {
                HelpersMethod.ClickBut(driver,CopyBut,20000);
                exists=true;
            }
            Assert.assertTrue(exists);
        }
        catch (Exception e) {}
    }
    public void CommentBut()
    {
        exists=false;
        try
        {
            exists=HelpersMethod.IsEnabledByele(Comment_But);
            if(exists)
            {
                HelpersMethod.ClickBut(driver,Comment_But,10000);
                scenario.log("COMMENT BUTTON HAS BEEN CLICKED");
            }
        }
        catch (Exception e) {}
    }
    //handling 'Comment' popup for order and for product
    public void Comment_Popup(String Comment)
    {
        exists=false;
        WebElement WebEle;
        WebElement flag;
        try
        {
            if(HelpersMethod.IsExists("//span[text()='Comments']/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                driver.findElement(By.id("textAreaA")).sendKeys(Comment);
                scenario.log("COMMENT ENTERED IS "+Comment);

                List<WebElement> printFlags=HelpersMethod.FindByElements(driver,"xpath","//ul[@id='printFlagDropDown-listbox-id']/descendant::span");
                for(int i=0;i<=printFlags.size()-1;i++)
                {
                    if(i==1)
                    {
                        flag=printFlags.get(i);
                        HelpersMethod.ActClick(driver,flag,10000);
                        break;
                    }
                }

                //Click on Add button in the popup
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]/descendant::button/span[text()='Add']");
                HelpersMethod.ClickBut(driver,WebEle,10000);

                //Click on OK button
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]/descendant::button/span[text()='Ok']");
                HelpersMethod.ClickBut(driver,WebEle,10000);
                exists=true;
            }
            Assert.assertTrue(exists);
        }
        catch (Exception e){}
    }

    //Find the no. rows in the summary grid and compare it with total no. of product
    public int Read_no_of_Product_Grid()
    {
        int count=0;
        try
        {
            count=driver.findElements(By.xpath("//table[@class='k-grid-table']/descendant::tr[contains(@class,'k-master-row')]")).size();
            scenario.log("NUMBER OF PRODUCTS FOUND IN SUMMARY PAGE "+ count);
        }
        catch (Exception e){}
        return count;
    }
    //Cancel Button in summary page
    public void Cancel_Button()
    {
        exists=false;
        try
        {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='ConfirmSummaryButton']//*[local-name()='svg']|//button[@id='ConfirmSummarySplitButton']//*[local-name()='svg']")));
            HelpersMethod.ScrollUpScrollBar(driver);
            if(HelpersMethod.IsExistsById("CancelSummaryButton",driver))
            {
                WebElement CancelBut = HelpersMethod.FindByElement(driver, "id", "CancelSummaryButton");
                if(CancelBut.isEnabled())
                {
                    HelpersMethod.ClickBut(driver, CancelBut, 10000);
                    exists = true;
                }
            }
            scenario.log("CANCEL ORDER BUTTON HAS BEEN CLICKED");
            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Cancel order')]/ancestor::div[contains(@class,'k-window k-dialog')]"))));
            Assert.assertTrue(exists);
        }
        catch (Exception e){}
    }

    public void VerifyCancelPopUp()
    {
        try
        {
            WebElement modalContainer = driver.findElement(By.xpath("//span[contains(text(),'Cancel order')]/ancestor::div[contains(@class,'k-window k-dialog')]"));

            // to fetch the web elements of the modal content and interact with them, code to fetch content of modal title and verify it
            WebElement modalContentTitle = modalContainer.findElement(By.xpath(".//span[contains(@class,'k-window-title k-dialog-title')]"));
            Assert.assertEquals(modalContentTitle.getText(), "Cancel order", "Verify Title message");
        }
        catch (Exception e){}
    }

    public void CancelPop()
    {
        exists=false;
        WebElement WebEle;
        try
        {
            //Check for the Cancel Order warning popup
            if (HelpersMethod.IsExists("//span[contains(text(),'Cancel order')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                WebElement cancelPopup = driver.findElement(By.xpath("//div[contains(@class,'k-window k-dialog')]"));
                WebEle=cancelPopup.findElement(By.xpath(".//button/span[text()='Yes']"));
                HelpersMethod.ActClick(driver,WebEle,10000);
                exists=true;
                scenario.log("CANCEL ORDER POPUP HAS BEEN HANDLED");
            }
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            Assert.assertTrue(exists);
        }
        catch (Exception e){}
    }
    //Click on uparrow button next to Product# column in Order summary page
    public void Product_UpArrow()
    {
        int i=0;
        Actions act=new Actions(driver);
        try
        {
            HelpersMethod.ActClick(driver,Button_Close,10000);
            //To zoom out browser by 50%
            if(TestBase.testEnvironment.get_browser().equalsIgnoreCase("chrome")|TestBase.testEnvironment.get_browser().equalsIgnoreCase("edge"))
            {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("document.body.style.zoom='50%'");
            }
            else if(TestBase.testEnvironment.get_browser().equalsIgnoreCase("firefox"))
            {
                JavascriptExecutor js=(JavascriptExecutor)driver;
                js.executeScript("document.body.style.MozTransform='50%'");
            }
            WebElement ProdNo=HelpersMethod.FindByElement(driver,"xpath","//span[text()='Product #']");
            HelpersMethod.JScriptClick(driver,ProdNo,10000);

            WebElement Sort=HelpersMethod.FindByElement(driver,"xpath","//span[text()='Product #']/following-sibling::span[contains(@class,'sort')]");
            act.moveToElement(Sort).doubleClick(Sort).build().perform();
            //find the column number for Product #
            List<WebElement> theads=HelpersMethod.FindByElements(driver,"xpath","//th[contains(@class,'k-header')]/descendant::span[@class='k-column-title']");
            for (WebElement head:theads)
            {
                i++;
                act.moveToElement(head).build().perform();
                String head_Text= head.getText();
                if(head_Text.equals("Product #"))
                {
                    break;
                }
            }

            //Creating list of webelements for Products in Order summary grid
            List<WebElement> Products=driver.findElements(By.xpath("//tr[contains(@class,'k-master-row')]/td["+i+"]/descendant::span[contains(@class,'CPKendoDataGrid-Label-rightmargin')]"));
            ArrayList<String> Pro_List=new ArrayList<>();
            for(WebElement Prod: Products)
            {
                Pro_List.add(Prod.getText());
            }
            //Creating sorted list of products in Summary grid
            ArrayList<String> Pro_Sort=new ArrayList<>(Pro_List);
            Collections.sort(Pro_Sort);
            //Comparing the sorted order with list of products
            if(Pro_Sort.equals(Pro_List))
            {
                scenario.log("PRODUCT NUMBERS ARE IN SORTED ORDER");
            }
            else
            {
                scenario.log("PRODUCT NUMBERS ARE NOT IN SORTED ORDER");
            }

            //To zoom out browser by 100%
            if(TestBase.testEnvironment.get_browser().equalsIgnoreCase("chrome")|TestBase.testEnvironment.get_browser().equalsIgnoreCase("edge"))
            {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("document.body.style.zoom='100%'");
            }
            else if(TestBase.testEnvironment.get_browser().equalsIgnoreCase("firefox"))
            {
                JavascriptExecutor js=(JavascriptExecutor)driver;
                js.executeScript("document.body.style.MozTransform='100%'");
            }
        }
        catch(Exception e){}
    }

    public void ClickOnAllOrder()
    {
        exists=false;
        WebElement WebEle;
        String status;
        if(HelpersMethod.IsExists("//div[@class='loader']",driver))
        {
            WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='loader']");
            HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 1000000);
        }
        WebEle=HelpersMethod.FindByElement(driver,"id","OpenOrdersButton_sbc");
        try
        {
            if(WebEle.isDisplayed() && WebEle.isEnabled())
            {
                HelpersMethod.ScrollElement(driver,WebEle);
                HelpersMethod.ActClick(driver, WebEle, 10000);
                if(HelpersMethod.IsExists("//div[@class='loader']",driver))
                {
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='loader']");
                    HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 1000000);
                }
                exists=true;
            }
            status=HelpersMethod.returnDocumentStatus(driver);
            if(status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            if(HelpersMethod.IsExists("//div[contains(text(),'Your order has not been submitted.')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]/descendant::button/span[contains(text(),'Submit order')]");
                HelpersMethod.ActClick(driver,WebEle,10000);
                if(HelpersMethod.IsExists("//div[@class='loader']",driver))
                {
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='loader']");
                    HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 1000000);
                }
            }
            Assert.assertTrue(exists);
        }
        catch (Exception e){}
    }

    public void PrintOE()
    {
        exists=false;
        WebElement WebEle;
        try
        {
            if(PrintBut.isDisplayed() && PrintBut.isEnabled())
            {
                HelpersMethod.ScrollElement(driver, PrintBut);
                String ParentWindow = driver.getWindowHandle();
                HelpersMethod.ClickBut(driver, PrintBut, 10000);
                Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(800))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(org.openqa.selenium.NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
                String status = HelpersMethod.returnDocumentStatus(driver);
                if (status.equals("loading"))
                {
                    HelpersMethod.waitTillLoadingPage(driver);
                }

                Thread.sleep(4000);

                Set<String> allWindows = driver.getWindowHandles();
                if (allWindows.size() > 1)
                {
                    for (String handle : allWindows)
                    {
                        if (!handle.equals(ParentWindow))
                        {
                            // Switch to each child window
                            driver.switchTo().window(handle);
                            // Optionally check the URL or title to confirm if this is the window you want to close
                            String url = driver.getCurrentUrl();
                            scenario.log("Closing window with URL: " + url);
                            Thread.sleep(500);
                            // Use JavaScript to force-close the window
                            ((JavascriptExecutor) driver).executeScript("window.close();");
                            Thread.sleep(1000);
                            exists = true;
                            Thread.sleep(1000);
                        }
                    }
                }
                Thread.sleep(1000);
                // Switch back to the parent window
                driver.switchTo().window(ParentWindow);
                scenario.log("YOU ARE IN MAIN WINDOW");
                exists = true;
            }
            else
            {
                scenario.log("PRINT BUTTON IS NOT ENABLED");
            }
            Assert.assertTrue(exists);
        }
        catch (Exception e){}
    }

    public void BackToOrderList()
    {
        exists=false;
        WebElement WebEle;
        try
        {
            HelpersMethod.ClickBut(driver,BackOrder,10000);
            exists=true;
            if(HelpersMethod.IsExists("//div[@class='loader']",driver))
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 1000000);
            }
            HelpersMethod.WaitElementPresent(driver,"id","order-search-card",10000);
            Assert.assertTrue(exists);
        }
        catch (Exception e){}
    }

    public void ValidateSummaryOrderPage()
    {
        exists=false;
        try
        {
           if(HelpersMethod.IsExists("//div[@id='SummaryCard']",driver))
           {
               exists=true;
           }
            Assert.assertTrue(exists);
        }
        catch (Exception e){}
    }

    public void PickupOrderValidate()
    {
        exists=false;
        try
        {
            if(HelpersMethod.IsExists("//div[@class='loader']",driver))
            {
                WebElement WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 1000000);
            }
            HelpersMethod.ScrollElement(driver,Comment_But);
            if(HelpersMethod.IsExists("//div[contains(text(),'Pick up order')]//following-sibling::div[text()='Yes']",driver))
            {
                scenario.log("PICKUP ORDER HAS BEEN SET AS YES");
                exists=true;
            }
            Assert.assertTrue(exists);
        }
        catch (Exception e){}
    }

    public void clickOnBackToOrderList()
    {
        exists=false;
        try
        {
            if(BackOrder.isDisplayed() && BackOrder.isEnabled())
            {
                HelpersMethod.ClickBut(driver,BackOrder,10000);
                exists=true;
            }
            Assert.assertTrue(exists);
        }
        catch (Exception e){}
    }

    public void validateCommentPopup()
    {
        exists=false;
        try
        {
            if(HelpersMethod.IsExists("//span[contains(text(),'Comments')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                scenario.log("COMMENT POPUP HAS BEEN FOUND");
               exists=true;
            }
            Assert.assertTrue(exists);
        }
        catch (Exception e){}
    }

    public void readComments()
    {
        exists=false;
        String com_Text;
        HashSet<String> comment_Text=new HashSet<>();
        List<String> comment_Text1 = new ArrayList<>();
        try
        {
            List<WebElement> comments=HelpersMethod.FindByElements(driver,"xpath","//div[contains(@class,'k-window k-dialog')]/descendant::tr[contains(@class,'k-master-row')]/descendant::td[2]");
            for(WebElement comment:comments)
            {
                com_Text=comment.getText();
                comment_Text1.add(com_Text);
                comment_Text.add(com_Text);
            }
            if(comment_Text.size()==comment_Text1.size())
            {
                scenario.log("NO DUPLICATE COMMENT HAS BEEN FOUND");
                exists=true;
            }
            else
            {
                scenario.log("DUPLICATE COMMENT HAS BEEN FOUND");
                exists=false;
            }
            Assert.assertTrue(exists);
        }
        catch (Exception e){}
    }

    public void clickOnOKCommentPopup()
    {
        exists=false;
        try
        {
            if(HelpersMethod.IsExists("//span[contains(text(),'Comments')]/ancestor::div[contains(@class,'k-window k-dialog')]/descendant::button/span[text()='Ok']",driver))
            {
                WebElement okButton=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]/descendant::button/span[text()='Ok']");
                HelpersMethod.ClickBut(driver,okButton,10000);
                exists=true;
            }
            Assert.assertTrue(exists);
        }
        catch (Exception e){}
    }

    public void compareTotal()
    {
        exists=false;
        String TotalProd,TotGrid;
        try
        {
           // TotalProd=driver.findElement(By.xpath("//div[contains(text(),'Total lines')]/following-sibling::div")).getText();
            TotGrid=Integer.toString(Read_no_of_Product_Grid());
            //Assert.assertEquals(TotalProd,TotGrid);
        }
        catch (Exception e){}
    }

    public void totalProducts()
    {
        Read_no_of_Product_Grid();
    }

    public void clickOnAllOrder()
    {
        exists=false;
        String status;
        WebElement WebEle;
        try
        {
            WebElement allOrder=HelpersMethod.FindByElement(driver,"id","OpenOrdersButton_sbc");
            HelpersMethod.ClickBut(driver,allOrder,10000);
            scenario.log("ORDER HAS BEEN FOUND IN ORDER ENTRY ALSO");
            status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            if(HelpersMethod.IsExists("//div[@class='loader']",driver))
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 1000000);
            }

            status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            if(HelpersMethod.IsExists("//div[@class='loader']",driver))
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 1000000);
            }
        }
        catch (Exception e){}
    }

    public boolean validateExistingOrderNotDisplayed()
    {
        exists=false;
        try
        {
            if(HelpersMethod.IsExists("//span[contains(text(),'Existing orders found')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                WebElement modelContainer=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]");
                WebElement yesButton=modelContainer.findElement(By.xpath(".//button/span[text()='Yes']"));
                HelpersMethod.ActClick(driver,yesButton,10000);
                scenario.log("<span style='color:red'> ADMIN SETTING FOR EXISTING ORDER HAS BEEN DISABLED BUT STILL ABLE TO SEE THE DIALOG BOX </span>");
                exists=false;
            }
            else
            {
                scenario.log("ADMIN SETTING FOR EXISTING ORDER HAS BEEN ENABLED AND NO DIALOG BOX IS FOUND!!!");
                exists=true;
            }
        }
        catch (Exception e){}
        return exists;
    }

    public boolean validateExistingOrderDisplayed()
    {
        exists=false;
        try
        {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            if(HelpersMethod.IsExists("//span[contains(text(),'Existing orders found')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                WebElement modelContainer=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]");
                WebElement yesButton=modelContainer.findElement(By.xpath(".//button/span[text()='Yes']"));
                HelpersMethod.ActClick(driver,yesButton,10000);

                wait = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(600))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

                scenario.log(" ADMIN SETTING FOR EXISTING ORDER HAS BEEN ENABLED, ABLE TO SEE ORDER EXISTS DIALOG BOX");
                exists=true;
            }
            else
            {
                scenario.log("<span style='color:red'> ADMIN SETTING FOR EXISTING ORDER HAS BEEN ENABLED AND NO DIALOG BOX IS FOUND!!!</span>");
                exists=false;
            }
        }
        catch (Exception e){}
        return exists;
    }

    public void  validateExistingOrderCancel()
    {
        exists=false;
        try
        {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            if(HelpersMethod.IsExists("//span[contains(text(),'Existing orders found')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                WebElement modelContainer=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]");
                WebElement cancelButton=modelContainer.findElement(By.xpath(".//button/span[text()='Cancel order']"));
                HelpersMethod.ActClick(driver,cancelButton,10000);

                wait = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(600))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

                scenario.log("ADMIN SETTING FOR EXISTING ORDER HAS BEEN ENABLED, AND CANCEL ORDER HAS BEEN SELECTED");
                exists=true;
            }
            else
            {
                scenario.log("CHECK FOR ADMIN SETTING, FOR EXISTING ORDER HAS BEEN ENABLED OR NOT AND NO DIALOG BOX IS FOUND!!!");
                exists=false;
            }
        }
        catch (Exception e){}
    }

    public void  validateExistingOrderNo()
    {
        exists=false;
        try
        {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            if(HelpersMethod.IsExists("//span[contains(text(),'Existing orders found')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                WebElement modelContainer=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]");
                WebElement noButton=modelContainer.findElement(By.xpath(".//button/span[text()='No']"));
                HelpersMethod.ActClick(driver,noButton,10000);

                wait = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(600))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

                scenario.log("ADMIN SETTING FOR EXISTING ORDER HAS BEEN ENABLED, AND NO HAS BEEN SELECTED");
                exists=true;
            }
            else
            {
                scenario.log("CHECK FOR ADMIN SETTING, FOR EXISTING ORDER HAS BEEN ENABLED OR NOT AND NO DIALOG BOX IS FOUND!!!");
                exists=false;
            }
        }
        catch (Exception e){}
    }

    public void percentageOfAverageProd()
    {
        try
        {
            WebElement WebEle;
            if (HelpersMethod.IsExists("//div[contains(text(),'% of your average order for the given products')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                Wait<WebDriver> wait  = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(600))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

                WebElement modalContainer = HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]");
                //click on Continue button
                WebEle=modalContainer.findElement(By.xpath(".//button/span[text()='Continue']"));
                HelpersMethod.ActClick(driver,WebEle, 10000);

                wait = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(600))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

                scenario.log("% OF YOUR AVERAGE ORDER POPUP HAS BEEN HANDLED");

                wait = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(600))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
            }
        }
        catch (Exception e){}
    }

    public void ClickSubmitOE()
    {
        exists=false;
        try
        {
            HelpersMethod.ScrollUpScrollBar(driver);
            Thread.sleep(1000);
            if(HelpersMethod.IsExists("//button[@id='ConfirmSummarySplitButton']",driver))
            {
                WebElement submitButton=HelpersMethod.FindByElement(driver,"id","ConfirmSummarySplitButton");
                //HelpersMethod.ScrollElement(driver,submitButton);
                HelpersMethod.ClickBut(driver,submitButton,20000);

                Wait<WebDriver> wait  = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(600))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void validatePaymentInSummary(String currenturl)
    {
        exists=false;
        String currenturlInSummary;
        try
        {
            if(HelpersMethod.IsExists("//div[contains(text(),'Payment info')]",driver))
            {
                currenturlInSummary=HelpersMethod.FindByElement(driver,"xpath","//div[contains(text(),'Payment info')]/following-sibling::span[1]").getText();
                if(currenturl.equals(currenturlInSummary))
                {
                    scenario.log("PAYMENT METHOD FOUND IS: "+currenturlInSummary);
                    exists=true;
                }
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void handleOrderSubmissionDialog()
    {
        exists=false;
        try
        {
            if(HelpersMethod.IsExists("//div[contains(text(),'Are you sure you want to leave this page?')]/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                WebElement submitDialog=HelpersMethod.FindByElement(driver,"xpath","//div[contains(@class,'k-window k-dialog')]/descendant::button/span[contains(text(),'Submit order')]");
                HelpersMethod.ActClick(driver,submitDialog,10000);
                exists=true;
                Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(600))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void readProductsFromOrderSummaryPage()
    {
        exists=false;
        String headText;
        Actions act=new Actions(driver);
        int i=0;
        try
        {
            if(HelpersMethod.IsExists("//span[@class='k-column-title']",driver))
            {
                List<WebElement> heads=HelpersMethod.FindByElements(driver,"xpath","//span[@class='k-column-title']");
                for(WebElement head:heads)
                {
                    act.moveToElement(head).build().perform();
                    headText=head.getText();
                    if(headText.equals("Product #"))
                    {
                        i++;
                        break;
                    }
                }
            }
            List<WebElement> prods=HelpersMethod.FindByElements(driver,"xpath","//tr[contains(@class,'k-master-row')]/td["+i+"]/descendant::span[contains(@class,'CPKendoDataGrid')]");
            for(WebElement prod:prods)
            {
                act.moveToElement(prod).build().perform();
                headText=prod.getText();
                scenario.log("PRODUCT# FOUND IN SUMMARY PAGE "+headText);
            }
        }
        catch (Exception e){}
    }

    public void pickupOrderElement()
    {
        exists=false;
        try
        {
            if(HelpersMethod.IsExists("//div[text()='Pick up order']/following-sibling::div[text()='Yes']",driver))
            {
                scenario.log("PICKUP ORDER HAS BEEN CREATED");
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }
}
