package pages_DSD_OMS.orderEntry;

import helper.HelpersMethod;
import io.cucumber.java.Scenario;
import io.cucumber.java.bs.A;
import lombok.experimental.Helper;
import org.apache.logging.log4j.core.tools.picocli.CommandLine;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.awt.*;
import java.time.Duration;
import java.util.List;

/**
 * @Project DSD_OMS
 * @Author Divya.Ramadas@afsi.com
 */
public class OrderHistoryPage
{
    /* Created by Divya */
    WebDriver driver;
    Scenario scenario;
    static boolean exists=false;

    @FindBy(id="customerAccountIndexSearchBar")
    private WebElement SearchBox;

    @FindBy(xpath="//*[local-name()='svg' and contains(@class,'i-search-box__search')]")
    private WebElement SearchIndex;

    @FindBy(xpath="//button[@id='copy-button']")
    private WebElement CopyButton;

    @FindBy(xpath="//button[@id='print-button']")
    private WebElement PrintButton;

    @FindBy(xpath="//button/span[@class='i-filter-tag__main']")
    private WebElement Addfilter;

    @FindBy(id="order-history-card")
    private WebElement HistoryGrid;

    @FindBy(xpath="//button[@id='view-orders-button']")
    private WebElement OrderButton;

    @FindBy(xpath="//span[@id='grid-selection-dropdown']/descendant::button")
    private WebElement gridType;

    //Actions
    public OrderHistoryPage(WebDriver driver, Scenario scenario) throws InterruptedException, AWTException
    {
        this.scenario=scenario;
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void ValidateOrderHistory()
    {
        exists=false;
        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                .withTimeout(Duration.ofSeconds(600))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

        try
        {

            if(HelpersMethod.IsExists("//div[@class='order-history']",driver))
            {
                scenario.log("IN ORDER HISTORY PAGE");
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void SearchBox_Entry(String Ord_No) throws InterruptedException
    {
        try
        {
            HelpersMethod.EnterText(driver,SearchBox, 10000,Ord_No);
            HelpersMethod.ClickBut(driver,SearchIndex,10000);
            scenario.log("ORDER NUMBER ENTERED FOR SEARCHING IN ORDER HISTORY PAGE IS "+Ord_No);
        }
        catch (Exception e){}
    }

    public void Check_Box()
    {
        WebElement WebEle;
        try
        {
            if(HelpersMethod.IsExists("//div[@class='loader']",driver))
            {
                WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 1000000);
            }
            HelpersMethod.waitTillElementLocatedDisplayed(driver,"xpath","//tr[contains(@class,'k-master-row')][1]/descendant::input[contains(@class,'k-checkbox')]",10);
            WebEle=HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row')][1]/descendant::input[contains(@class,'k-checkbox')]");
            HelpersMethod.ScrollElement(driver,WebEle);
            HelpersMethod.ClickBut(driver,WebEle,1000);
        }
        catch (Exception e){}
    }
    public void Copy_Button()
    {
        exists=false;
        try
        {
            new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfAllElementsLocatedBy(By.id("order-history-card"))));
            if(!HelpersMethod.IsExists("//button[@id='copy-button' and contains(@class,'k-disabled')]",driver))
            {
                HelpersMethod.ScrollElement(driver, CopyButton);
                HelpersMethod.ClickBut(driver, CopyButton, 40000);
                scenario.log("COPY BUTTON HAS BEEN CLICKED, TO COPY ORDER HISTORY");
                exists=true;
                Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(600))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void Click_OrderNo()
    {
        exists=false;
        WebElement WebEle;
        String Ord;
        try
        {
            WebEle=HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row')][1]/descendant::button/span[@class='i-link-button']");
            Ord=WebEle.getText();
            scenario.log("ORDER NUMBER SELECTED IN ORDER HISTORY PAGE IS "+Ord);
            HelpersMethod.ScrollElement(driver,WebEle);
            HelpersMethod.ClickBut(driver,WebEle,10000);
            exists=true;
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public boolean VerifiyHistoryGrid() throws InterruptedException
    {
        exists=false;
        String status = HelpersMethod.returnDocumentStatus(driver);
        if (status.equals("loading"))
        {
            HelpersMethod.waitTillLoadingPage(driver);
        }
        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                .withTimeout(Duration.ofSeconds(600))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

        if (HelpersMethod.IsExists("//div[@id='order-history-card']", driver))
        {
            exists=true;
        }
        Assert.assertEquals(exists, true);
        return exists;
    }

    public void Click_CheckBox()
    {
        exists=false;
        try
        {
            if(HelpersMethod.IsExists("//tr[contains(@class,'k-master-row')][1]/descendant::input[contains(@class,'k-checkbox')]",driver))
            {
                //code to select first order in order history
                WebElement OrderHist = HelpersMethod.FindByElement(driver, "xpath", "//tr[contains(@class,'k-master-row')][1]/descendant::input[contains(@class,'k-checkbox')]");
                HelpersMethod.ActClick(driver, OrderHist, 10000);
            }
            else
            {
                scenario.log("CHECK BOX IS NOT VISIBLE IN ORDER HISTORY GRID");
            }
            exists=true;
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void Click_On_RowIn_OrderHistoryGrid()
    {
        Actions act1=new Actions(driver);
        String statusText;
        exists=false;
        int i=0;
        try
        {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            String status1 = HelpersMethod.returnDocumentStatus(driver);
            if (status1.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }

            wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            //creating list of 'status' column value to find active order and to neglect skip and cancel orders
            List<WebElement> status=HelpersMethod.FindByElements(driver,"xpath","//tr[contains(@class,'k-master-row')]/descendant::span[contains(@class,'status-cell')]");
            for(WebElement sta:status)
            {
              i++;
              act1.moveToElement(sta).build().perform();
              statusText=sta.getText();
              if(statusText.equalsIgnoreCase("ACTIVE")||statusText.equalsIgnoreCase("OPEN ORDER")||statusText.equalsIgnoreCase("DELIVERED")||statusText.equalsIgnoreCase("ORDER SUBMITTED"))
              {
                  //Read the Order number
                  WebElement OrderNo=HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row')]["+i+"]/descendant::button");
                  scenario.log("ORDER NUMBER SELECTED FROM ORDER HISTORY PAGE FOR CREATING COPY IS: "+OrderNo.getText());

                  //code to select first order in order history
                  WebElement OrderHist = HelpersMethod.FindByElement(driver, "xpath", "//tr[contains(@class,'k-master-row')]["+i+"]/td[2]");
                  act1.moveToElement(OrderHist).build().perform();
                  act1.click().build().perform();
                  exists=true;
                  break;
              }
          }
            wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            status1 = HelpersMethod.returnDocumentStatus(driver);
            if (status1.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }

            wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            new WebDriverWait(driver, Duration.ofMillis(10000)).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfAllElementsLocatedBy(By.id("order-history-card"))));
            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.id("order-history-card")));
            Thread.sleep(4000);
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void VerifyCommentInHistory()
    {
        exists=false;
        WebElement WebEle;
        Actions act= new Actions(driver);
        String Comm_Text;
        try
        {
            if(HelpersMethod.IsExists("//tr[contains(@class,'k-master-row')]//*[local-name()='svg']//*[local-name()='path' and contains(@d,'17 L 4 5 z')] | //tr[contains(@class,'k-master-row')]//*[local-name()='svg']//*[local-name()='path' and contains(@d,'17 L 4 3 z')]",driver))
            {
                if (HelpersMethod.IsExists("//tr[contains(@class,'k-master-row')][1]//*[local-name()='svg']//*[local-name()='path' and contains(@d,'17 L 4 5 z')]", driver))
                {
                    scenario.log("COMMENT HAS NOT BEEN ADDED TO THE SELECTED ORDER IN ORDER HISTORY");
                }
                else
                {
                    WebEle=HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row')]//*[local-name()='svg']//*[local-name()='path' and contains(@d,'17 L 4 3 z')]");
                    HelpersMethod.ClickBut(driver,WebEle,10000);
                    scenario.log("COMMENTS FOUND ARE:");
                    List<WebElement> Comments = HelpersMethod.FindByElements(driver, "xpath", "//div[contains(@class,'k-window k-dialog')]/descendant::tr[contains(@class,'k-master-row')]/td[2]");
                    for (WebElement Comment : Comments)
                    {
                        act.moveToElement(Comment).build().perform();
                        Comm_Text = Comment.getText();
                        scenario.log("COMMENT IN ORDER " + Comm_Text);
                    }
                }
            }
            else
            {
                scenario.log("COMMENT ICON HAS NOT BEEN FOUND");
            }
        }
        catch (Exception e){}
    }

    public void OrderButtonClick()
    {
        exists=false;
        try
        {
            HelpersMethod.ClickBut(driver,OrderButton,10000);
            exists=true;
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    //public void FilterActiveOrder(String s,String s1,String s2,String s3)
    public void FilterActiveOrder()
    {
        WebElement WebEle;
        exists=false;
        try
        {
            Actions act=new Actions(driver);
            WebEle= HelpersMethod.FindByElement(driver,"xpath","//div[@class='i-grid']");
            HelpersMethod.ScrollElement(driver,WebEle);
            WebElement headTitle=HelpersMethod.FindByElement(driver,"xpath","//th[contains(@class,'k-header')]/descendant::span[@class='k-column-title' and contains(text(),'Delivery Date')]");

            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            act.moveToElement(headTitle).doubleClick().build().perform();
            exists=true;
            wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            String status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }
            wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='k-grid k-grid-md']"))));
            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='k-grid k-grid-md']")));

            Thread.sleep(1000);
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void selectDeliveryDate() throws InterruptedException
    {
        try
        {
            if (HelpersMethod.IsExists("//span[contains(text(),'Select delivery date')]/ancestor::div[contains(@class,'k-window k-dialog')]", driver))
            {
                WebElement selectDeliveryDate = HelpersMethod.FindByElement(driver, "xpath", "//div/span[contains(text(),'Select delivery date')]/ancestor::div[contains(@class,'k-window k-dialog')]");
                WebElement newOrder = selectDeliveryDate.findElement(By.xpath(".//tr[contains(@class,'k-master-row')][1]"));
                scenario.log("DELIVERY DATE SELECTED IS: " + selectDeliveryDate.findElement(By.xpath(".//span[@class='line2']")).getText());
                HelpersMethod.ActClick(driver, newOrder, 10000);

                Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(600))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

                String status = HelpersMethod.returnDocumentStatus(driver);
                if (status.equals("loading"))
                {
                    HelpersMethod.waitTillLoadingPage(driver);
                }
                wait = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(600))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
            }
        }
        catch (Exception e){}
    }

    public void selectNewOrderPopup()
    {
        WebElement WebEle;
        try
        {
            String status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }

            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            status = HelpersMethod.returnDocumentStatus(driver);
            if (status.equals("loading"))
            {
                HelpersMethod.waitTillLoadingPage(driver);
            }

            wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            //handling Select order no. popup
            if(HelpersMethod.IsExists("//div[contains(text(),'Select order')]/ancestor::div[contains(@class,'modal-content')]",driver))
            {
                WebElement modalContainer = driver.findElement(By.xpath("//div[contains(@class,'modal-content')]"));

                WebEle=modalContainer.findElement(By.xpath(".//div[@class='list-group']/div[text()='New order']"));
                HelpersMethod.ActClick(driver,WebEle,10000);

                wait = new FluentWait<WebDriver>(driver)
                        .withTimeout(Duration.ofSeconds(600))
                        .pollingEvery(Duration.ofSeconds(2))
                        .ignoring(NoSuchElementException.class);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
            }

            //handling note popup
            if(HelpersMethod.IsExists("//div[@id='customerNotesDialog']/ancestor::div[contains(@class,'k-window k-dialog')]",driver))
            {
                WebElement modalContainer = driver.findElement(By.xpath("//div[@id='customerNotesDialog']/ancestor::div[contains(@class,'k-window k-dialog')]"));

                WebEle= modalContainer.findElement(By.xpath(".//button/span[text()='Ok']"));
                HelpersMethod.ClickBut(driver,WebEle,10000);
            }
        }
        catch (Exception e){}
    }

    public void clickOnGridType()
    {
        exists=false;
        try
        {
            if(HelpersMethod.IsExists("//span[@id='grid-selection-dropdown']/descendant::button",driver))
            {
                HelpersMethod.JScriptClick(driver,gridType,20000);
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void selectAnyGridType()
    {
        exists=false;
        Actions act1=new Actions(driver);
        String optText;
        try
        {
            List<WebElement> Options=HelpersMethod.FindByElements(driver,"xpath","//ul[@id='grid-selection-dropdown-listbox-id']/descendant::span[@class='k-list-item-text']");
            for(WebElement opt:Options)
            {
                act1.moveToElement(opt).build().perform();
                optText=opt.getText();
                if (!optText.equals("Main grid"))
                {
                    act1.moveToElement(opt).build().perform();
                    act1.click(opt).build().perform();
                    exists=true;
                    break;
                }
            }
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void selectGridType()
    {
        exists=false;
        Actions act1=new Actions(driver);
        String optText;
        try
        {
            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@id='grid-selection-dropdown-listbox-id']/descendant::span[@class='k-list-item-text']"))));
            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@id='grid-selection-dropdown-listbox-id']/descendant::span[@class='k-list-item-text']")));
            List<WebElement> Options=HelpersMethod.FindByElements(driver,"xpath","//ul[@id='grid-selection-dropdown-listbox-id']/descendant::span[@class='k-list-item-text']");
            for(WebElement opt:Options)
            {
                act1.moveToElement(opt).build().perform();
                optText=opt.getText();
                if (optText.equals("Main grid"))
                {
                    act1.moveToElement(opt).build().perform();
                    act1.click(opt).build().perform();
                    exists=true;
                    break;
                }
            }
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void validateGridType()
    {
            exists=false;
            try
            {
                String gridValue=HelpersMethod.FindByElement(driver,"xpath","//span[@id='grid-selection-dropdown']/descendant::span[@class='k-input-value-text']").getText();
                if(gridValue.equals("Main grid"))
                {
                    scenario.log("GRID TYPE SELECTED IS "+gridValue);
                    exists=true;
                }
                Assert.assertEquals(exists,true);
            }
            catch (Exception e){}
    }

    public void selectGridTypeNotMain()
    {
        exists=false;
        Actions act1=new Actions(driver);
        String optText;
        try
        {
            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@id='grid-selection-dropdown-listbox-id']/li/span"))));
            new WebDriverWait(driver,Duration.ofMillis(10000)).until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@id='grid-selection-dropdown-listbox-id']/li/span"))));
            List<WebElement> Options=HelpersMethod.FindByElements(driver,"xpath","//ul[@id='grid-selection-dropdown-listbox-id']/li/span");
            //for (int i=0;i<=Options.size()-1;i++)
            for(WebElement opt:Options)
            {
                act1.moveToElement(opt).build().perform();
                optText=opt.getText();
                if (!optText.equals("Main grid"))
                {
                    act1.moveToElement(opt).build().perform();
                    act1.click(opt).build().perform();
                    exists=true;
                    break;
                }
            }
            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                    .withTimeout(Duration.ofSeconds(600))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='loader']")));

            String gridName=HelpersMethod.FindByElement(driver,"xpath","//span[@id='grid-selection-dropdown']/descendant::span[@class='k-input-value-text']").getText();
            scenario.log("GRID SELECTED IS "+gridName);
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void validateGridTypeNotMain()
    {
        exists=false;
        try
        {
            String gridValue=HelpersMethod.FindByElement(driver,"xpath","//span[@id='grid-selection-dropdown']/descendant::span[@class='k-input-value-text']").getText();
            if(!gridValue.equals("Main grid"))
            {
                scenario.log("GRID TYPE SELECTED IS "+gridValue);
                exists=true;
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void clickOnOrderButton()
    {
        exists=false;
        try
        {
            if(OrderButton.isDisplayed() && OrderButton.isEnabled())
            {
                HelpersMethod.ClickBut(driver,OrderButton,10000);
                exists=true;
                if(HelpersMethod.IsExists("//div[@class='loader']",driver))
                {
                    WebElement WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='loader']");
                    HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 1000000);
                }
            }
            Assert.assertEquals(exists,true);
        }
        catch (Exception e){}
    }

    public void Click_On_OrderNumber()
    {
        exists=false;
        try
        {
            //Read the Order number
            WebElement OrderNo=HelpersMethod.FindByElement(driver,"xpath","//tr[contains(@class,'k-master-row')][1]/descendant::button");
            scenario.log("ORDER NUMBER SELECTED FROM ORDER HISTORY PAGE FOR CREATING COPY IS: "+OrderNo.getText());

            HelpersMethod.ClickBut(driver,OrderNo,10000);
            if(HelpersMethod.IsExists("//div[@class='loader']",driver))
            {
                WebElement WebEle=HelpersMethod.FindByElement(driver,"xpath","//div[@class='loader']");
                HelpersMethod.waitTillLoadingWheelDisappears(driver, WebEle, 1000000);
            }
        }
        catch (Exception e){}
    }
}
